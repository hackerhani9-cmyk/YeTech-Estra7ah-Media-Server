Place educational videos, audio, or documents under this folder.

Create one folder per series, then add season folders and video files. Example: series/Example Show/Season 01/S01E01.mp4.

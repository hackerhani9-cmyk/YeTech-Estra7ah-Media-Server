Place movie files in this folder. Supported formats include MP4, MKV, AVI, MOV, and WebM.

# Local media library

Put media into category folders such as `movies/`, `series/`, `audio/`, `books/`, `apps/`, and `education/`.
Series are grouped by show folder and season folder. The scanner runs at startup and can be run again from the library page.

Demo files are created with `pnpm --filter @workspace/api-server run demo:media`.

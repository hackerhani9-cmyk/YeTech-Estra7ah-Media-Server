# Download inbox

Place completed media files here. The server checks that each file stops changing before moving it into `backend/media/` and indexing it.
Temporary and unsupported files are left in this folder.

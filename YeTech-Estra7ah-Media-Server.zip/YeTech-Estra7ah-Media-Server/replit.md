# YeTech Estra7ah Media Server

Arabic-first media library for streaming and downloading locally stored media over a trusted home LAN.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/yetech-media run dev` — run the web interface
- `pnpm --filter @workspace/api-server run demo:media` — create sample WAV/PDF files, a demo episode and an inbox item; FFmpeg also adds MP4/HLS samples
- `docker compose up --build -d` — run the full stack on a computer on the home LAN
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Optional env: `TMDB_API_KEY` for online cast/poster enrichment, `LOCAL_AI_ENDPOINT`/`LOCAL_AI_MODEL` for a LAN-hosted LLM, and `MEDIA_ROOT`/`DOWNLOADS_ROOT` to change local folders

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: SQLite at `backend/data/media.db` via Node's built-in SQLite module
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- Web UI: `artifacts/yetech-media`
- API: `artifacts/api-server`
- OpenAPI source of truth: `lib/api-spec/openapi.yaml`
- SQLite, media and download inbox: `backend/data/`, `backend/media/` and `backend/downloads/`
- Docker Compose: root `docker-compose.yml`

## Architecture decisions

- The app uses its own SQLite file because it must run on a local host without internet access.
- Replit preview is hosted and cannot reach a home LAN or local media disk while offline; use the Docker Compose stack on the LAN host for offline playback.
- TMDB enrichment and RSS downloads are optional online features; a configured local AI endpoint can enrich text metadata without internet. Local scanning, inbox imports, playback, and downloads remain available offline.
- RSS feed URLs that resolve to private LAN addresses are blocked unless `ALLOW_PRIVATE_RSS_HOSTS=true` is explicitly set.

## Product

Browse, search, and stream the local library; inspect series cast and seasons; manage optional RSS watchers; and configure per-client download bandwidth.

## User preferences

- Arabic RTL interface.
- Dark navy interface with blue accents.

## Gotchas

- Direct video/audio streaming uses native browser requests so HTTP Range seeking remains available.
- Mount local media under the configured `MEDIA_ROOT`; the scanner ignores symlinks.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

# YeTech Estra7ah Media Server

An Arabic RTL media library for streaming locally stored video and audio, browsing books and apps, and managing optional RSS downloads over a trusted home network.

## Quick start on a LAN host

1. Install Docker Engine and the Docker Compose plugin on the computer that will hold the media.
2. Put media in `backend/media/` using its category folders.
3. Start the services:

   ```bash
   docker compose up --build -d
   ```

4. Open `http://<LAN-IP-of-the-server>:3000` from a device on the same Wi-Fi/LAN. The app and media files are served by the local host; playback does not need internet access.

For a quick sample library, run `pnpm --filter @workspace/api-server run demo:media` before starting Docker. It creates WAV/PDF/movie/series samples and a small inbox item; with FFmpeg it also creates an HLS sample. Start Compose and the inbox watcher will move the inbox sample after it is stable.

## Media folders and database

- `backend/media/` contains the local media folders and can be mounted to a drive on the LAN host.
- `backend/data/media.db` is the SQLite catalog. It is created and migrated automatically when the API starts.
- `backend/downloads/` is an inbox for completed files from other download tools. The watcher waits for a file to stop changing, then safely moves it into the matching media category and rescans the library.
- If you have files from the earlier `backend/storage/` layout, that folder is left untouched but is not scanned by default; copy those files into `backend/media/` or update `MEDIA_ROOT` and its Compose volume.
- The scanner updates file sizes and indexes new files without replacing manually enriched metadata.
- Series are grouped by their first-level folder. Episode folders such as `Season 01` and filenames such as `S01E01` are detected automatically.
- From the LAN host, mount a disk into `backend/media` or one of its category folders (for example, `backend/media/series`).

The normal Docker startup is self-contained. Internet is needed only for optional TMDB enrichment or enabled RSS feeds. RSS watchers start only after a feed is configured.

## Optional enrichment and automation

- Cast, character names, bios, and posters can be enriched with TMDB when internet is available. For offline AI text metadata, configure `LOCAL_AI_ENDPOINT` to a trusted OpenAI-compatible local endpoint (for example `http://host.docker.internal:11434/v1/chat/completions`) and set `LOCAL_AI_MODEL` if needed. Streaming and browsing do not depend on either provider.
- For Compose, copy `backend/.env.example` to the project-root `.env` and fill in only the providers you want to use. A local model endpoint keeps text enrichment on your LAN; TMDB requires internet access.
- RSS feed watchers accept direct links to supported media files. Configure a relative destination such as `movies/`, `series/Show Name/Season 01/`, or `audio/`. Completed downloads trigger a library rescan.
- Private-network feed URLs are blocked by default to reduce server-side request forgery risk. Set `ALLOW_PRIVATE_RSS_HOSTS=true` only when you trust the configured feed source and need it to be on the LAN.
- The per-client download cap is configured in Settings in Mbps. `0` means unlimited. The initial cap and watcher interval can also be set with `DOWNLOAD_LIMIT_MBPS` and `WATCH_INTERVAL_MINUTES`.

## Replit preview versus offline LAN use

The Replit preview runs in Replit's hosted environment; it cannot reach files or devices on a home LAN when the internet is down. To meet the offline playback requirement, run the included Compose stack on the computer that stores the media and keep it on the local network. Publishing the Replit preview does not turn it into a home-LAN server.

Keep this server on a trusted LAN. Do not expose the API or the Docker host directly to the public internet.


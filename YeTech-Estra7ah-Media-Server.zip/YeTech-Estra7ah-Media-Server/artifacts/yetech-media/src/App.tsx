import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  useCheckRssFeeds,
  useCreateRssFeed,
  useDeleteRssFeed,
  useDownloadMedia,
  useEnrichMediaItem,
  useGetDownloadJobs,
  useGetMediaItem,
  useGetMediaItems,
  useGetMediaStats,
  useGetRssFeeds,
  useGetServerSettings,
  useHealthCheck,
  useScanMediaLibrary,
  useUpdateServerSettings,
  getGetDownloadJobsQueryKey,
  getGetMediaItemQueryKey,
  getGetMediaItemsQueryKey,
  getGetMediaStatsQueryKey,
  getGetRssFeedsQueryKey,
  getGetServerSettingsQueryKey,
  getStreamMediaUrl,
  getDownloadMediaQueryKey,
} from '@workspace/api-client-react';
import type { DownloadJob, Episode, GetMediaItemsParams, MediaItem, MediaType, RssFeedInput } from '@workspace/api-client-react';
import type Hls from 'hls.js';
import {
  Activity, BookOpen, Check, Clapperboard, Download, FileText, Film,
  HardDrive, LayoutGrid, LoaderCircle, Music2, Play, Plus, Radio, RefreshCw,
  Search, Settings2, Sparkles, Trash2, Wifi, X,
  UserRound,
} from 'lucide-react';
import './media-details.css';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const labels: Record<MediaType, string> = {
  movie: 'أفلام', series: 'مسلسلات', book: 'كتب', audio: 'صوتيات', app: 'تطبيقات', education: 'تعليم',
};
const icons: Record<MediaType, typeof Film> = {
  movie: Film, series: Clapperboard, book: BookOpen, audio: Music2, app: LayoutGrid, education: FileText,
};
const typeFilters: Array<{ value: MediaType | ''; label: string }> = [
  { value: '', label: 'الكل' }, { value: 'movie', label: 'أفلام' }, { value: 'series', label: 'مسلسلات' },
  { value: 'book', label: 'كتب' }, { value: 'audio', label: 'صوتيات' }, { value: 'app', label: 'تطبيقات' }, { value: 'education', label: 'تعليم' },
];

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} كيلوبايت`;
  if (bytes < 1024 ** 3) return `${(bytes / 1024 / 1024).toFixed(1)} ميغابايت`;
  return `${(bytes / 1024 ** 3).toFixed(1)} غيغابايت`;
}
function formatDuration(seconds?: number | null) {
  if (!seconds) return '';
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return hours ? `${hours} س ${minutes} د` : `${minutes} دقيقة`;
}
function formatDate(date?: string | null) {
  if (!date) return 'لم يتم الفحص بعد';
  return new Intl.DateTimeFormat('ar', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(date));
}
function errText(error: unknown) {
  return error instanceof Error ? error.message : 'تعذّر إكمال الطلب. تحقق من اتصال الشبكة المحلية وحاول مجدداً.';
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const health = useHealthCheck();
  const nav = [
    { href: '/', label: 'المكتبة', icon: LayoutGrid },
    { href: '/downloads', label: 'التنزيلات', icon: Download },
    { href: '/settings', label: 'الإعدادات', icon: Settings2 },
  ];
  return <div className="dark app-shell" dir="rtl">
    <aside className="sidebar">
      <div className="brand-lockup"><div className="brand-mark">YT</div><div className="brand-copy"><div className="brand-name">YeTech</div><div className="brand-sub">استراحة العائلة</div></div></div>
      <nav className="nav-list" aria-label="التنقل الرئيسي">{nav.map(({ href, label, icon: Icon }) =>
        <Link key={href} href={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`link-nav-${href === '/' ? 'library' : href.slice(1)}`}>
          <Icon size={18} strokeWidth={1.8} /><span className="nav-label">{label}</span>
        </Link>)}</nav>
      <div className="sidebar-bottom"><span className="online-dot" />{health.isLoading ? 'جارٍ الاتصال بالشبكة المحلية' : health.isError ? 'الخادم غير متصل' : 'الخادم المحلي متصل'}<br />مكتبتك معك، حتى دون إنترنت</div>
    </aside>
    <main className="main-area">
      <header className="topbar"><span className="topbar-label">شبكتك المحلية · مكتبتك الخاصة</span><div className="topbar-actions"><span className="topbar-label"><Wifi size={15} style={{ verticalAlign: 'middle', marginLeft: 6 }} /> يعمل دون إنترنت</span></div></header>
      {children}
    </main>
  </div>;
}

function Heading({ title, subtitle, children }: { title: string; subtitle: string; children?: ReactNode }) {
  return <div className="page-heading"><div><h1 className="page-title">{title}</h1><p className="page-subtitle">{subtitle}</p></div>{children}</div>;
}
function Toast({ text, onClose }: { text: string; onClose: () => void }) {
  useEffect(() => { const timer = window.setTimeout(onClose, 3600); return () => window.clearTimeout(timer); }, [onClose]);
  return <div className="toast-note" role="status" data-testid="status-toast">{text}</div>;
}

function HomePage() {
  const [search, setSearch] = useState('');
  const [type, setType] = useState<MediaType | ''>('');
  const [selected, setSelected] = useState<number | null>(null);
  const [toast, setToast] = useState('');
  const queryClient = useQueryClient();
  const params = useMemo<GetMediaItemsParams>(() => ({ limit: 100, ...(search.trim() ? { search: search.trim() } : {}), ...(type ? { type } : {}) }), [search, type]);
  const stats = useGetMediaStats({ query: { queryKey: getGetMediaStatsQueryKey(), refetchInterval: 15000 } });
  const items = useGetMediaItems(params, { query: { queryKey: getGetMediaItemsQueryKey(params), refetchInterval: 15000 } });
  const scan = useScanMediaLibrary({ mutation: { onSuccess: async (result) => {
    await Promise.all([queryClient.invalidateQueries({ queryKey: getGetMediaItemsQueryKey() }), queryClient.invalidateQueries({ queryKey: getGetMediaStatsQueryKey() })]);
    setToast(`اكتمل الفحص: أضيف ${result.added}، حُدّث ${result.updated}، مفقود ${result.missing}`);
  }, onError: (error) => setToast(errText(error)) } });
  const loading = stats.isLoading || items.isLoading;
  const itemList = items.data ?? [];
  return <><section className="content">
    <Heading title="مكتبة الاستراحة" subtitle="كل ما تحبونه، محفوظ على شبكتكم وجاهز للمشاهدة والاستماع.">
      <button className="btn btn-primary" onClick={() => scan.mutate()} disabled={scan.isPending} data-testid="button-scan-library">
        {scan.isPending ? <LoaderCircle size={16} className="spin" /> : <RefreshCw size={16} />}{scan.isPending ? 'جارٍ الفحص' : 'فحص المكتبة'}
      </button>
    </Heading>
    <div className="stats-strip">
      <div className="stat-card"><div className="stat-icon"><LayoutGrid size={19} /></div><div><div className="stat-value" data-testid="text-library-total">{stats.data?.total ?? '—'}</div><div className="stat-label">عنصر في المكتبة</div></div></div>
      <div className="stat-card"><div className="stat-icon"><HardDrive size={19} /></div><div><div className="stat-value" data-testid="text-library-size">{stats.data ? formatBytes(stats.data.totalBytes) : '—'}</div><div className="stat-label">مساحة محفوظة محلياً</div></div></div>
      <div className="stat-card"><div className="stat-icon"><Activity size={19} /></div><div><div className="stat-value">{stats.data?.byType.length ?? '—'}</div><div className="stat-label">أقسام متنوعة</div></div></div>
    </div>
    <div className="section-heading"><div><h2>تصفّح مكتبتك</h2><span className="section-count" data-testid="text-results-count">{items.isLoading ? 'جارٍ تحميل المكتبة' : `${itemList.length} عنصر`}</span></div></div>
    <div className="searchbar"><Search size={18} color="var(--muted-foreground)" /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحث عن فيلم، كتاب، أو مادة تعليمية..." aria-label="البحث في المكتبة" data-testid="input-library-search" /></div>
    <div className="filters" role="group" aria-label="تصفية حسب النوع">{typeFilters.map((filter) =>
      <button key={filter.value || 'all'} className={`filter-chip ${type === filter.value ? 'selected' : ''}`} onClick={() => setType(filter.value)} data-testid={`filter-type-${filter.value || 'all'}`}>{filter.label}</button>)}</div>
    {items.isError ? <div className="error-state" data-testid="state-library-error"><div className="empty-icon"><Wifi size={23} /></div><h3>تعذّر الوصول إلى المكتبة</h3><p>{errText(items.error)}</p><button className="btn btn-outline" onClick={() => { void items.refetch(); void stats.refetch(); }} data-testid="button-retry-library"><RefreshCw size={15} />حاول مجدداً</button></div>
      : loading ? <div className="media-grid" aria-label="جارٍ تحميل العناصر">{Array.from({ length: 8 }, (_, index) => <div key={index}><div className="skeleton skeleton-poster" /><div className="skeleton skeleton-line" /></div>)}</div>
      : itemList.length === 0 ? <div className="empty-state" data-testid="state-library-empty"><div className="empty-icon"><BookOpen size={22} /></div><h3>{search || type ? 'لم نعثر على عناصر مطابقة' : 'مكتبتك بانتظار أول محتوى'}</h3><p>{search || type ? 'جرّب كلمات أخرى أو اختر قسماً مختلفاً.' : 'أضف ملفاتك إلى مجلدات الخادم المحلي، ثم افحص المكتبة.'}</p>{!search && !type && <button className="btn btn-outline" onClick={() => scan.mutate()} disabled={scan.isPending} data-testid="button-first-scan"><RefreshCw size={15} />فحص المكتبة</button>}</div>
        : <div className="media-grid">{itemList.map((item) => <MediaCard key={item.id} item={item} onSelect={() => setSelected(item.id)} />)}</div>}
  </section>
  {selected !== null && <MediaModal id={selected} onClose={() => setSelected(null)} onToast={setToast} />}
  {toast && <Toast text={toast} onClose={() => setToast('')} />}
  </>;
}

function MediaCard({ item, onSelect }: { item: MediaItem; onSelect: () => void }) {
  const Icon = icons[item.type] ?? FileText;
  return <article className="media-card" role="button" tabIndex={0} onClick={onSelect} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') onSelect(); }} data-testid={`card-media-${item.id}`}>
    <div className="poster" style={!item.posterUrl ? { background: posterColor(item.id) } : undefined}>
      {item.posterUrl ? <img src={item.posterUrl} alt="" loading="lazy" data-testid={`img-poster-${item.id}`} /> : <div className="poster-art"><span className="poster-meta">{item.releaseYear ?? 'YeTech'}</span><span className="poster-title">{item.title}</span><span className="poster-meta">{labels[item.type]}</span></div>}
      <span className="poster-type"><Icon size={12} style={{ verticalAlign: 'middle', marginLeft: 4 }} />{labels[item.type]}</span>
    </div><div className="media-title" data-testid={`text-title-${item.id}`}>{item.title}</div><p className="media-caption">{item.releaseYear ?? item.category ?? labels[item.type]}</p>
  </article>;
}
function posterColor(id: number) {
  const colors = ['linear-gradient(145deg,#1d3763,#172747 65%,#101827)', 'linear-gradient(145deg,#26385c,#202b45 58%,#111827)', 'linear-gradient(145deg,#283c5b,#1c2b48 65%,#0f172a)', 'linear-gradient(145deg,#1e3a5f,#1d2d4e 58%,#111827)', 'linear-gradient(145deg,#334155,#1e293b 55%,#0f172a)'];
  return colors[id % colors.length];
}

function MediaModal({ id, onClose, onToast }: { id: number; onClose: () => void; onToast: (message: string) => void }) {
  const detail = useGetMediaItem(id, { query: { queryKey: getGetMediaItemQueryKey(id) } });
  const enrich = useEnrichMediaItem({ mutation: { onSuccess: (result) => onToast(result.message), onError: (error) => onToast(errText(error)) } });
  const download = useDownloadMedia(id, { query: { enabled: false, queryKey: getDownloadMediaQueryKey(id) } });
  const [playing, setPlaying] = useState(false);
  const [activeEpisode, setActiveEpisode] = useState<Episode | null>(null);
  const item = detail.data;
  const streamId = activeEpisode?.id ?? id;
  const streamUrl = `${getStreamMediaUrl(streamId)}${activeEpisode ? '?episode=true' : ''}`;
  const isHls = activeEpisode?.fileExtension === '.m3u8' || item?.fileExtension === '.m3u8';
  async function downloadFile() {
    try {
      const result = await download.refetch();
      if (!result.data) return;
      const url = URL.createObjectURL(result.data);
      const anchor = document.createElement('a');
      anchor.href = url; anchor.download = `${item?.title ?? 'ملف'}`; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
      onToast('بدأ تنزيل الملف إلى جهازك');
    } catch (error) { onToast(errText(error)); }
  }
  const downloadable = item?.type === 'book' || item?.type === 'app';
  return <div className="overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="media-dialog-title" data-testid={`dialog-media-${id}`}>
      <div className="dialog-head"><h2 id="media-dialog-title">{item?.title ?? 'تفاصيل المادة'}</h2><button className="icon-button" onClick={onClose} aria-label="إغلاق" data-testid="button-close-details"><X size={18} /></button></div>
      <div className="dialog-body">
        {detail.isLoading ? <div className="detail-hero"><div className="skeleton detail-poster" /><div><div className="skeleton" style={{ height: 24, width: '70%', marginBottom: 18 }} /><div className="skeleton" style={{ height: 80 }} /></div></div>
          : detail.isError || !item ? <div className="error-state"><h3>تعذّر تحميل التفاصيل</h3><p>{errText(detail.error)}</p><button className="btn btn-outline" onClick={() => void detail.refetch()} data-testid="button-retry-detail">حاول مجدداً</button></div>
            : <>
              <div className="detail-hero"><div className="detail-poster">{item.posterUrl ? <img src={item.posterUrl} alt="" /> : <div className="poster-art" style={{ background: posterColor(item.id) }}><span className="poster-title">{item.title}</span><span>{labels[item.type]}</span></div>}</div>
                <div className="detail-info"><span className="setting-kicker">{labels[item.type]}{item.releaseYear ? ` · ${item.releaseYear}` : ''}</span><h1>{item.title}</h1>
                  <div className="detail-tags">{item.genres?.map((genre) => <span className="tag" key={genre}>{genre}</span>)}<span className="tag">{formatBytes(item.fileSize)}</span>{item.durationSeconds ? <span className="tag">{formatDuration(item.durationSeconds)}</span> : null}</div>
                  <p className="detail-overview">{item.overview || 'هذه المادة محفوظة في مكتبتكم المحلية وجاهزة للاستمتاع بها.'}</p>
                  <div className="detail-actions">{downloadable ? <button className="btn btn-primary" onClick={() => void downloadFile()} disabled={download.isFetching} data-testid="button-download-media">{download.isFetching ? <LoaderCircle size={16} /> : <Download size={16} />}{download.isFetching ? 'جارٍ التجهيز' : 'تنزيل إلى الجهاز'}</button>
                    : <button className="btn btn-primary" onClick={() => { if (item.type === 'series' && item.episodes?.length) setActiveEpisode(item.episodes[0]); else setActiveEpisode(null); setPlaying(true); }} disabled={item.type === 'series' && !item.episodes?.length} data-testid="button-play-media"><Play size={16} />تشغيل الآن</button>}
                    <button className="btn btn-outline" onClick={() => enrich.mutate({ id })} disabled={enrich.isPending} data-testid="button-enrich-media">{enrich.isPending ? <LoaderCircle size={16} /> : <Sparkles size={16} />}{enrich.isPending ? 'جارٍ تحديث البيانات' : 'تحديث بيانات المادة'}</button></div>
                </div></div>
      {item.type === 'book' && item.fileExtension === '.pdf' && <section className="pdf-reader" aria-label="قارئ الكتب" data-testid={`pdf-reader-${item.id}`}><div className="section-heading"><h2>قارئ PDF</h2><span className="section-count">عرض محلي</span></div><iframe src={getStreamMediaUrl(item.id)} title={`قراءة ${item.title}`} loading="lazy" data-testid={`iframe-pdf-${item.id}`} /></section>}
      {item.cast?.length > 0 && <section className="cast-section"><div className="section-heading"><h2>طاقم العمل</h2><span className="section-count">{item.cast.length} مشارك</span></div><div className="cast-carousel" role="list">{item.cast.slice(0, 16).map((person) => <article className="cast-card" role="listitem" key={person.id} data-testid={`card-cast-${person.id}`}>{person.profilePath ? <img src={person.profilePath} alt={person.name} loading="lazy" data-testid={`img-cast-${person.id}`} /> : <div className="cast-placeholder" aria-hidden="true"><UserRound size={24} /></div>}<strong>{person.name}</strong><span>{person.characterName || person.originalName || 'طاقم العمل'}</span></article>)}</div></section>}
      {item.episodes?.length > 0 && <section><div className="section-heading"><h2>الحلقات</h2><span className="section-count">{item.episodes.length} حلقة</span></div><div className="job-list">{item.episodes.map((episode) => <div className="job-row" key={episode.id} data-testid={`row-episode-${episode.id}`}><div className="feed-symbol"><Play size={16} /></div><div className="job-details"><strong>الموسم {episode.seasonNumber} · الحلقة {episode.episodeNumber} — {episode.title}</strong><span>{formatDuration(episode.durationSeconds)} · {formatBytes(episode.fileSize)}</span></div><button className="icon-button" aria-label={`تشغيل ${episode.title}`} onClick={() => { setActiveEpisode(episode); setPlaying(true); }} data-testid={`button-play-episode-${episode.id}`}><Play size={15} /></button></div>)}</div></section>}
            </>}
      </div>
    </section>
    {playing && item && <div className="overlay" style={{ zIndex: 60 }} onMouseDown={(event) => { if (event.target === event.currentTarget) setPlaying(false); }}><div className="dialog" style={{ width: 'min(900px,100%)' }}><div className="dialog-head"><h2>{activeEpisode?.title ?? item.title}</h2><button className="icon-button" onClick={() => setPlaying(false)} aria-label="إغلاق المشغل" data-testid="button-close-player"><X size={18} /></button></div><div className="dialog-body" style={{ background: '#090d16' }}><Player type={item.type} src={streamUrl} title={item.title} isHls={Boolean(isHls)} /><p style={{ color: '#cbd5e1', fontSize: 12, margin: '12px 0 0' }}>يتم التشغيل مباشرة من الخادم المحلي، مع دعم التقديم والاستكمال.</p></div></div></div>}
  </div>;
}

function Player({ type, src, title, isHls }: { type: MediaType; src: string; title: string; isHls: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [nativeHlsSupported, setNativeHlsSupported] = useState(false);
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const supportsNativeHls =
      video.canPlayType('application/vnd.apple.mpegurl') !== '';
    setNativeHlsSupported(supportsNativeHls);
    if (type === 'audio' || !isHls || supportsNativeHls) return;

    let disposed = false;
    let hls: Hls | null = null;
    void import('hls.js').then(({ default: HlsPlayer }) => {
      if (disposed || !HlsPlayer.isSupported()) return;
      hls = new HlsPlayer({ enableWorker: true });
      hls.loadSource(src);
      hls.attachMedia(video);
    });
    return () => {
      disposed = true;
      hls?.destroy();
    };
  }, [isHls, src, type]);
  return type === 'audio' ? <audio controls autoPlay src={src} aria-label={title} style={{ width: '100%', margin: '24px 0' }} data-testid="player-audio" /> :
    <video ref={videoRef} controls autoPlay playsInline src={isHls && !nativeHlsSupported ? undefined : src} aria-label={title} style={{ width: '100%', maxHeight: '65vh', background: '#090d16', borderRadius: 10 }} data-testid="player-video" />;
}

function DownloadsPage() {
  const queryClient = useQueryClient();
  const feeds = useGetRssFeeds({ query: { queryKey: getGetRssFeedsQueryKey(), refetchInterval: 10000 } });
  const jobs = useGetDownloadJobs({ query: { queryKey: getGetDownloadJobsQueryKey(), refetchInterval: 1500 } });
  const check = useCheckRssFeeds({ mutation: { onSuccess: async (result) => {
    await Promise.all([queryClient.invalidateQueries({ queryKey: getGetDownloadJobsQueryKey() }), queryClient.invalidateQueries({ queryKey: getGetRssFeedsQueryKey() })]);
    setToast(result.message || `تم فحص ${result.feedsChecked} موجزات وبدء ${result.jobsStarted} تنزيلات`);
  }, onError: (error) => setToast(errText(error)) } });
  const [formOpen, setFormOpen] = useState(false);
  const [toast, setToast] = useState('');
  return <><section className="content">
    <Heading title="التنزيلات والموجزات" subtitle="تابع المحتوى الجديد القادم إلى مكتبتك المحلية.">
      <button className="btn btn-outline" onClick={() => check.mutate()} disabled={check.isPending} data-testid="button-check-feeds"><RefreshCw size={15} className={check.isPending ? 'spin' : ''} />{check.isPending ? 'جارٍ الفحص' : 'فحص الموجزات الآن'}</button>
    </Heading>
    {check.isError && <div className="error-state" style={{ padding: 15, marginBottom: 16 }}><p>{errText(check.error)}</p><button className="btn btn-outline" onClick={() => check.mutate()} data-testid="button-retry-feed-check">إعادة المحاولة</button></div>}
    <section className="panel"><div className="panel-title"><div><h2>موجزات المتابعة</h2><p>مصادر RSS التي تراقبها المكتبة تلقائياً</p></div><button className="btn btn-primary" onClick={() => setFormOpen(true)} data-testid="button-add-feed"><Plus size={16} />إضافة موجز</button></div>
      {feeds.isLoading ? <LoadingRows /> : feeds.isError ? <ErrorInline message={errText(feeds.error)} retry={() => void feeds.refetch()} testId="state-feeds-error" /> : (feeds.data?.length ?? 0) === 0 ? <div className="empty-state" style={{ padding: 34 }} data-testid="state-feeds-empty"><div className="empty-icon"><Radio size={21} /></div><h3>لا توجد موجزات متابعة</h3><p>أضف موجزاً لمتابعة الإصدارات الجديدة تلقائياً.</p></div> :
        <div className="feed-list">{feeds.data?.map((feed) => <FeedRow key={feed.id} feed={feed} onToast={setToast} />)}</div>}
    </section>
    <section className="panel"><div className="panel-title"><div><h2>حالة التنزيلات</h2><p>آخر المهام التي بدأتها الموجزات</p></div><span className="status-pill">{jobs.data?.length ?? 0} مهمة</span></div>
      {jobs.isLoading ? <LoadingRows /> : jobs.isError ? <ErrorInline message={errText(jobs.error)} retry={() => void jobs.refetch()} testId="state-jobs-error" /> : (jobs.data?.length ?? 0) === 0 ? <div className="empty-state" style={{ padding: 34 }} data-testid="state-jobs-empty"><div className="empty-icon"><Download size={21} /></div><h3>لا توجد تنزيلات بعد</h3><p>ستظهر هنا المهام التي تبدأها موجزات RSS.</p></div> : <div className="job-list">{jobs.data?.map((job) => <JobRow key={job.id} job={job} />)}</div>}
    </section>
  </section>
  {formOpen && <FeedDialog onClose={() => setFormOpen(false)} onToast={setToast} />}
  {toast && <Toast text={toast} onClose={() => setToast('')} />}
  </>;
}
function FeedRow({ feed, onToast }: { feed: { id: number; title: string; feedUrl: string; destinationPath: string; matchCriteria: string | null; enabled: boolean; lastCheckedAt?: string | null }; onToast: (text: string) => void }) {
  const client = useQueryClient();
  const remove = useDeleteRssFeed({ mutation: { onSuccess: async () => { await client.invalidateQueries({ queryKey: getGetRssFeedsQueryKey() }); onToast('تم حذف موجز المتابعة'); }, onError: (error) => onToast(errText(error)) } });
  function removeFeed() {
    if (window.confirm(`حذف موجز «${feed.title}»؟`)) remove.mutate({ id: feed.id });
  }
  return <div className="feed-row" data-testid={`row-feed-${feed.id}`}><div className="feed-symbol"><Radio size={18} /></div><div className="feed-details"><strong>{feed.title}</strong><span dir="ltr" style={{ textAlign: 'right' }}>{feed.feedUrl}</span><span>المجلد: {feed.destinationPath}{feed.matchCriteria ? ` · يطابق: ${feed.matchCriteria}` : ''}</span><span>آخر فحص: {formatDate(feed.lastCheckedAt)}</span></div>
    <span className={`status-pill ${feed.enabled ? 'active' : ''}`} data-testid={`status-feed-${feed.id}`}>{feed.enabled ? 'مفعّل' : 'متوقف'}</span>
    <button className="icon-button" onClick={removeFeed} disabled={remove.isPending} aria-label="حذف الموجز" data-testid={`button-delete-feed-${feed.id}`}><Trash2 size={16} /></button>
  </div>;
}
function JobRow({ job }: { job: DownloadJob }) {
  const status: Record<string, string> = { pending: 'بانتظار البدء', downloading: 'جارٍ التنزيل', completed: 'اكتمل', failed: 'تعذّر التنزيل' };
  const className = job.status === 'completed' ? 'active' : job.status === 'failed' ? 'failed' : '';
  return <div className="job-row" data-testid={`row-job-${job.id}`}><div className="feed-symbol"><Download size={17} /></div><div className="job-details"><strong>{job.title}</strong><span>{job.destinationPath} · بدأ {formatDate(job.createdAt)}</span>{job.status === 'downloading' && <div className="progress-track" role="progressbar" aria-valuenow={job.downloadProgress} aria-valuemin={0} aria-valuemax={100} data-testid={`progress-job-${job.id}`}><div className="progress-fill" style={{ width: `${Math.min(100, Math.max(0, job.downloadProgress))}%` }} /></div>}</div><span className={`status-pill ${className}`} data-testid={`status-job-${job.id}`}>{status[job.status] ?? job.status}{job.status === 'downloading' ? ` · ${Math.round(job.downloadProgress)}٪` : ''}</span></div>;
}
function FeedDialog({ onClose, onToast }: { onClose: () => void; onToast: (text: string) => void }) {
  const client = useQueryClient();
  const create = useCreateRssFeed({ mutation: { onSuccess: async () => { await client.invalidateQueries({ queryKey: getGetRssFeedsQueryKey() }); onToast('تمت إضافة موجز المتابعة'); onClose(); }, onError: (error) => onToast(errText(error)) } });
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const body: RssFeedInput = { title: String(data.get('title') ?? '').trim(), feedUrl: String(data.get('feedUrl') ?? '').trim(), destinationPath: String(data.get('destinationPath') ?? '').trim(), matchCriteria: String(data.get('matchCriteria') ?? '').trim() || null, enabled: data.get('enabled') === 'on' };
    create.mutate({ data: body });
  }
  return <div className="overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="feed-form-title"><div className="dialog-head"><h2 id="feed-form-title">إضافة موجز متابعة</h2><button className="icon-button" onClick={onClose} aria-label="إغلاق" data-testid="button-close-feed-form"><X size={18} /></button></div>
    <form className="dialog-body" onSubmit={submit}><div className="form-grid">
      <div className="field full"><label htmlFor="feed-title">اسم الموجز</label><input required id="feed-title" name="title" placeholder="مثال: إصدارات العائلة" data-testid="input-feed-title" /></div>
      <div className="field full"><label htmlFor="feed-url">رابط موجز RSS</label><input required type="url" id="feed-url" name="feedUrl" dir="ltr" placeholder="https://example.org/feed.xml" data-testid="input-feed-url" /></div>
      <div className="field full"><label htmlFor="feed-path">مجلد الحفظ</label><input required id="feed-path" name="destinationPath" dir="ltr" placeholder="movies/ أو series/اسم المسلسل/Season 01/" data-testid="input-feed-destination" /></div>
      <div className="field full"><label htmlFor="feed-match">كلمات مطابقة <span className="field-help">(اختياري)</span></label><input id="feed-match" name="matchCriteria" placeholder="اسم السلسلة أو الكلمات المطلوبة" data-testid="input-feed-match" /></div>
      <label className="switch-line full"><input type="checkbox" name="enabled" defaultChecked data-testid="input-feed-enabled" /> تفعيل المتابعة فور الإضافة</label>
    </div><div className="form-actions"><button className="btn btn-primary" type="submit" disabled={create.isPending} data-testid="button-save-feed">{create.isPending ? 'جارٍ الحفظ' : 'حفظ الموجز'}</button><button className="btn btn-outline" type="button" onClick={onClose} data-testid="button-cancel-feed">إلغاء</button></div></form>
  </section></div>;
}

function SettingsPage() {
  const client = useQueryClient();
  const settings = useGetServerSettings();
  const save = useUpdateServerSettings({ mutation: { onSuccess: async () => { await client.invalidateQueries({ queryKey: getGetServerSettingsQueryKey() }); setToast('تم حفظ إعدادات الخادم'); }, onError: (error) => setToast(errText(error)) } });
  const [bandwidth, setBandwidth] = useState('');
  const [interval, setInterval] = useState('');
  const [toast, setToast] = useState('');
  useEffect(() => {
    if (settings.data) { setBandwidth(String(settings.data.downloadLimitMbps)); setInterval(String(settings.data.watchIntervalMinutes)); }
  }, [settings.data]);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    save.mutate({ data: { downloadLimitMbps: Number(bandwidth), watchIntervalMinutes: Number(interval) } });
  }
  return <><section className="content"><Heading title="إعدادات الخادم" subtitle="تحكّم في سرعة التنزيل ومواعيد فحص المصادر على شبكتك." />
    {settings.isLoading ? <><div className="skeleton" style={{ height: 180, marginBottom: 18 }} /><div className="skeleton" style={{ height: 120 }} /></> :
      settings.isError ? <ErrorInline message={errText(settings.error)} retry={() => void settings.refetch()} testId="state-settings-error" /> :
        <form onSubmit={submit}>
          <section className="panel"><div className="panel-title"><div><h2>التنزيلات والمتابعة</h2><p>إعدادات تؤثر على حركة البيانات داخل الشبكة</p></div><span className="feed-symbol"><Settings2 size={18} /></span></div>
            <div className="setting-row"><div><h3>حد سرعة التنزيل</h3><p>أقصى سرعة مشتركة بالميغابت في الثانية. استخدم صفر دون حد.</p></div><div className="field"><input aria-label="حد سرعة التنزيل بالميغابت" type="number" min="0" max="10000" step="1" value={bandwidth} onChange={(event) => setBandwidth(event.target.value)} required data-testid="input-download-limit" /><span className="field-help">ميغابت / ثانية</span></div></div>
            <div className="setting-row"><div><h3>فترة فحص موجزات RSS</h3><p>المدة بين عمليات فحص المصادر تلقائياً.</p></div><div className="field"><input aria-label="فترة فحص الموجزات بالدقائق" type="number" min="1" max="1440" step="1" value={interval} onChange={(event) => setInterval(event.target.value)} required data-testid="input-watch-interval" /><span className="field-help">دقيقة</span></div></div>
            <div className="form-actions"><button className="btn btn-primary" type="submit" disabled={save.isPending} data-testid="button-save-settings">{save.isPending ? <LoaderCircle size={15} /> : <Check size={15} />}{save.isPending ? 'جارٍ الحفظ' : 'حفظ الإعدادات'}</button></div>
          </section>
          <section className="panel"><div className="panel-title"><div><h2>الخادم المحلي</h2><p>حالة اتصال التطبيق بالخدمات المتاحة</p></div></div>
            <div className="setting-row"><div><h3>حالة الشبكة</h3><p>اتصال الواجهة بخادم YeTech على الشبكة المحلية</p></div><HealthBadge /></div>
            <div className="setting-row"><div><h3>مزود بيانات الذكاء الاصطناعي</h3><p>يدعم نموذجاً محلياً على الشبكة أو TMDB عند توفر الإنترنت.</p></div><span className={`status-pill ${settings.data?.metadataProviderConfigured ? 'active' : ''}`} data-testid="status-metadata-provider">{settings.data?.metadataProviderConfigured ? 'مُعدّ' : 'غير مُعدّ'}</span></div>
          </section>
        </form>}
  </section>{toast && <Toast text={toast} onClose={() => setToast('')} />}</>;
}
function HealthBadge() {
  const health = useHealthCheck();
  return <span className={`status-pill ${health.isSuccess ? 'active' : health.isError ? 'failed' : ''}`} data-testid="status-server-health">{health.isLoading ? 'جارٍ التحقق' : health.isSuccess ? 'متصل' : 'غير متصل'}</span>;
}
function LoadingRows() {
  return <div style={{ display: 'grid', gap: 10 }} aria-label="جارٍ التحميل">{[1, 2, 3].map((index) => <div key={index} className="skeleton" style={{ height: 70 }} />)}</div>;
}
function ErrorInline({ message, retry, testId }: { message: string; retry: () => void; testId: string }) {
  return <div className="error-state" style={{ padding: 28 }} data-testid={testId}><h3>تعذّر تحميل البيانات</h3><p>{message}</p><button className="btn btn-outline" onClick={retry} data-testid={`button-retry-${testId}`}><RefreshCw size={15} />حاول مجدداً</button></div>;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/"><AppShell><HomePage /></AppShell></Route>
    <Route path="/downloads"><AppShell><DownloadsPage /></AppShell></Route>
    <Route path="/settings"><AppShell><SettingsPage /></AppShell></Route>
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
export default App;

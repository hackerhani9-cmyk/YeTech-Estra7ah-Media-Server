import app from "./app";
import { logger } from "./lib/logger";
import { scanMediaLibrary } from "./lib/media-library";
import { startDownloadInboxWatcher } from "./lib/download-inbox-watcher";
import { startDownloadsWatcher } from "./lib/rss-watcher";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  try {
    const result = scanMediaLibrary();
    logger.info(result, "Media library scanned at startup");
  } catch (error) {
    logger.error(
      { error: error instanceof Error ? error.message : "Unknown error" },
      "Initial media scan failed",
    );
  }
  startDownloadsWatcher();
  startDownloadInboxWatcher();
});

import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const mediaRoot = path.resolve(
  process.env.MEDIA_ROOT ?? path.resolve(process.cwd(), "../../backend/media"),
);
const downloadsRoot = path.resolve(
  process.env.DOWNLOADS_ROOT ??
    path.resolve(process.cwd(), "../../backend/downloads"),
);

function writeWave(filePath) {
  const sampleRate = 44_100;
  const seconds = 2;
  const sampleCount = sampleRate * seconds;
  const dataBytes = sampleCount * 2;
  const buffer = Buffer.alloc(44 + dataBytes);
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataBytes, 4);
  buffer.write("WAVE", 8);
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataBytes, 40);
  for (let index = 0; index < sampleCount; index += 1) {
    const envelope = Math.min(1, index / 800, (sampleCount - index) / 800);
    const sample =
      Math.sin((2 * Math.PI * 440 * index) / sampleRate) * 0.17 * envelope;
    buffer.writeInt16LE(Math.round(sample * 32_767), 44 + index * 2);
  }
  fs.writeFileSync(filePath, buffer);
}

function writePdf(filePath) {
  const stream = "BT /F1 18 Tf 60 760 Td (YeTech Estra7ah demo library) Tj ET";
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`,
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  for (const [index, object] of objects.entries()) {
    offsets.push(Buffer.byteLength(pdf));
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  }
  const xrefOffset = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const offset of offsets.slice(1)) {
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  fs.writeFileSync(filePath, pdf);
}

for (const folder of ["movies", "series", "books", "audio", "apps", "education"]) {
  fs.mkdirSync(path.join(mediaRoot, folder), { recursive: true });
}
fs.mkdirSync(downloadsRoot, { recursive: true });

writeWave(path.join(mediaRoot, "audio", "YeTech sample tone.wav"));
writePdf(path.join(mediaRoot, "books", "YeTech sample booklet.pdf"));

const ffmpeg = spawnSync(
  "ffmpeg",
  [
    "-hide_banner",
    "-loglevel",
    "error",
    "-y",
    "-f",
    "lavfi",
    "-i",
    "color=c=0x143a3a:s=640x360:d=3:r=24",
    "-vf",
    "drawtext=text='YeTech LAN playback sample':fontcolor=white:fontsize=24:x=(w-text_w)/2:y=(h-text_h)/2",
    "-an",
    "-pix_fmt",
    "yuv420p",
    path.join(mediaRoot, "movies", "YeTech LAN playback sample.mp4"),
  ],
  { stdio: "ignore" },
);
const seriesDirectory = path.join(
  mediaRoot,
  "series",
  "YeTech sample series",
  "Season 01",
);
fs.mkdirSync(seriesDirectory, { recursive: true });
const sampleMoviePath = path.join(
  mediaRoot,
  "movies",
  "YeTech LAN playback sample.mp4",
);
if (fs.existsSync(sampleMoviePath)) {
  fs.copyFileSync(sampleMoviePath, path.join(seriesDirectory, "S01E01 - Demo.mp4"));
  fs.copyFileSync(
    sampleMoviePath,
    path.join(downloadsRoot, "YeTech inbox sample S01E02.mp4"),
  );
}
const hlsDirectory = path.join(mediaRoot, "movies");
fs.mkdirSync(hlsDirectory, { recursive: true });
const hlsPlaylist = path.join(mediaRoot, "movies", "YeTech HLS demo.m3u8");
const hls = spawnSync(
  "ffmpeg",
  [
    "-hide_banner",
    "-loglevel",
    "error",
    "-y",
    "-f",
    "lavfi",
    "-i",
    "color=c=0x234b4a:s=640x360:d=3:r=24",
    "-an",
    "-c:v",
    "libx264",
    "-preset",
    "ultrafast",
    "-pix_fmt",
    "yuv420p",
    "-g",
    "24",
    "-keyint_min",
    "24",
    "-sc_threshold",
    "0",
    "-hls_time",
    "1",
    "-hls_list_size",
    "0",
    "-hls_segment_filename",
    path.join(hlsDirectory, "YeTech HLS segment%03d.ts"),
    "-f",
    "hls",
    hlsPlaylist,
  ],
  { stdio: "ignore" },
);

console.log(
  JSON.stringify({
    mediaRoot,
    downloadsRoot,
    generated: [
      "audio/YeTech sample tone.wav",
      "books/YeTech sample booklet.pdf",
      "series/YeTech sample series/Season 01/S01E01 - Demo.mp4",
      "downloads/YeTech inbox sample S01E02.mp4",
    ],
    video: ffmpeg.status === 0 ? "generated" : "skipped (ffmpeg not installed)",
    hls: hls.status === 0 ? "generated" : "skipped (ffmpeg HLS support unavailable)",
  }),
);

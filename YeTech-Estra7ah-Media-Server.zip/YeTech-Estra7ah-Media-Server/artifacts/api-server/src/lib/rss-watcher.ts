import dns from "node:dns/promises";
import fs from "node:fs";
import net from "node:net";
import path from "node:path";
import { Transform, Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { XMLParser } from "fast-xml-parser";
import { logger } from "../lib/logger";
import { enrichMediaItem } from "./enrichment";
import { mediaRoot, scanMediaLibrary } from "./media-library";
import { getSetting, sqlite } from "./sqlite";

const parser = new XMLParser({
  ignoreAttributes: false,
  removeNSPrefix: true,
  textNodeName: "#text",
});
const supportedExtensions = new Set([
  ".mp4",
  ".mkv",
  ".avi",
  ".mov",
  ".webm",
  ".m4v",
  ".mp3",
  ".wav",
  ".m4a",
  ".aac",
  ".ogg",
  ".flac",
  ".pdf",
  ".epub",
  ".mobi",
  ".apk",
  ".zip",
]);
const maxDownloadBytes = Number(process.env.MAX_DOWNLOAD_BYTES ?? 20 * 1024 ** 3);
const privateFeedsAllowed = process.env.ALLOW_PRIVATE_RSS_HOSTS === "true";
const allowedRoots = [
  mediaRoot,
  ...(process.env.STORAGE_ALLOWED_ROOTS ?? "")
    .split(path.delimiter)
    .map((root) => root.trim())
    .filter(Boolean)
    .map((root) => path.resolve(root)),
];

interface FeedRow {
  id: number;
  title: string;
  feed_url: string;
  destination_path: string;
  match_criteria: string | null;
  enabled: number;
}

interface FeedEntry {
  guid: string;
  title: string;
  url: string;
}

function isPrivateIpv4(address: string): boolean {
  const octets = address.split(".").map(Number);
  if (octets.length !== 4 || octets.some((part) => Number.isNaN(part))) return true;
  const [a, b] = octets;
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    a >= 224
  );
}

function isPrivateAddress(address: string): boolean {
  const version = net.isIP(address);
  if (version === 4) return isPrivateIpv4(address);
  if (version === 6) {
    const normalized = address.toLowerCase();
    return (
      normalized === "::" ||
      normalized === "::1" ||
      normalized.startsWith("fc") ||
      normalized.startsWith("fd") ||
      normalized.startsWith("fe8") ||
      normalized.startsWith("fe9") ||
      normalized.startsWith("fea") ||
      normalized.startsWith("feb") ||
      normalized.startsWith("::ffff:127.") ||
      normalized.startsWith("::ffff:10.") ||
      normalized.startsWith("::ffff:192.168.")
    );
  }
  return true;
}

async function validateRemoteUrl(rawUrl: string): Promise<URL> {
  const url = new URL(rawUrl);
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Only HTTP and HTTPS feed links are supported.");
  }
  if (url.username || url.password) {
    throw new Error("Feed URLs cannot contain embedded credentials.");
  }
  if (privateFeedsAllowed) return url;
  if (net.isIP(url.hostname)) {
    if (isPrivateAddress(url.hostname)) {
      throw new Error("Private network feed addresses are blocked by default.");
    }
    return url;
  }
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) {
    throw new Error("Local network feed addresses are blocked by default.");
  }
  const addresses = await dns.lookup(host, { all: true });
  if (!addresses.length || addresses.some((entry) => isPrivateAddress(entry.address))) {
    throw new Error("Feed host must resolve to a public address.");
  }
  return url;
}

async function fetchRemote(
  rawUrl: string,
  timeoutMs: number,
  maxRedirects = 4,
): Promise<Response> {
  let currentUrl = rawUrl;
  for (let redirectCount = 0; redirectCount <= maxRedirects; redirectCount += 1) {
    const safeUrl = await validateRemoteUrl(currentUrl);
    const response = await fetch(safeUrl, {
      redirect: "manual",
      signal: AbortSignal.timeout(timeoutMs),
      headers: { "User-Agent": "YeTech-Estra7ah/1.0" },
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      await response.body?.cancel();
      if (!location || redirectCount === maxRedirects) {
        throw new Error("RSS source redirected too many times or omitted a destination.");
      }
      currentUrl = new URL(location, safeUrl).toString();
      continue;
    }
    return response;
  }
  throw new Error("Unable to follow RSS source.");
}

function toText(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number") return String(value);
  if (value && typeof value === "object" && "#text" in value) {
    return toText((value as Record<string, unknown>)["#text"]);
  }
  return "";
}

function getEntryUrl(entry: Record<string, unknown>): string {
  const enclosure = entry.enclosure as Record<string, unknown> | undefined;
  const mediaContent = entry.content as Record<string, unknown> | undefined;
  const enclosureUrl = toText(enclosure?.["@_url"] ?? enclosure?.url);
  if (enclosureUrl) return enclosureUrl;
  const mediaUrl = toText(mediaContent?.["@_url"] ?? mediaContent?.url);
  if (mediaUrl) return mediaUrl;

  const links = Array.isArray(entry.link) ? entry.link : [entry.link];
  for (const link of links) {
    if (typeof link === "string" && link.trim()) return link.trim();
    if (link && typeof link === "object") {
      const linkRecord = link as Record<string, unknown>;
      const href = toText(linkRecord["@_href"] ?? linkRecord.href);
      const relation = toText(linkRecord["@_rel"] ?? linkRecord.rel);
      if (href && (!relation || relation === "enclosure")) return href;
    }
  }
  return "";
}

function parseFeedEntries(xml: string): FeedEntry[] {
  const parsed = parser.parse(xml) as Record<string, unknown>;
  const feedRoot = (parsed.rss ?? parsed.feed ?? parsed) as Record<string, unknown>;
  const channel = (feedRoot.channel ?? feedRoot) as Record<string, unknown>;
  const rawItems = channel.item ?? channel.entry ?? [];
  const items = Array.isArray(rawItems) ? rawItems : [rawItems];
  return items.flatMap((value, index) => {
    if (!value || typeof value !== "object") return [];
    const entry = value as Record<string, unknown>;
    const title = toText(entry.title) || `New media item ${index + 1}`;
    const url = getEntryUrl(entry);
    if (!url) return [];
    const guid =
      toText(entry.guid) || toText(entry.id) || url;
    return [{ guid, title, url }];
  });
}

async function readLimitedText(
  response: Response,
  maximumBytes: number,
): Promise<string> {
  if (!response.body) return "";
  const reader = response.body.getReader();
  const chunks: Buffer[] = [];
  let totalBytes = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const chunk = Buffer.from(value);
      totalBytes += chunk.length;
      if (totalBytes > maximumBytes) {
        await reader.cancel();
        throw new Error("RSS feed is larger than 2 MB.");
      }
      chunks.push(chunk);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks, totalBytes).toString("utf8");
}

function matchesCriteria(title: string, criteria: string | null): boolean {
  if (!criteria?.trim()) return true;
  return criteria
    .split(/[,\n|;]/)
    .map((term) => term.trim().toLocaleLowerCase())
    .filter(Boolean)
    .some((term) => title.toLocaleLowerCase().includes(term));
}

function destinationDirectory(destinationPath: string): {
  root: string;
  directory: string;
} {
  const requestedPath = path.resolve(destinationPath);
  let root = allowedRoots.find(
    (candidate) =>
      requestedPath === candidate ||
      requestedPath.startsWith(`${candidate}${path.sep}`),
  );
  if (!root) {
    if (path.isAbsolute(destinationPath)) {
      throw new Error("Destination must be inside the configured media folder.");
    }
    root = mediaRoot;
  }
  const directory = path.isAbsolute(destinationPath)
    ? requestedPath
    : path.resolve(root, destinationPath);
  if (directory !== root && !directory.startsWith(`${root}${path.sep}`)) {
    throw new Error("Destination is outside the configured media folder.");
  }
  fs.mkdirSync(directory, { recursive: true });
  const realRoot = fs.realpathSync(root);
  const realDirectory = fs.realpathSync(directory);
  if (
    realDirectory !== realRoot &&
    !realDirectory.startsWith(`${realRoot}${path.sep}`)
  ) {
    throw new Error("Destination resolves outside the configured media folder.");
  }
  return { root: realRoot, directory: realDirectory };
}

export async function validateFeedConfiguration(
  feedUrl: string,
  destinationPath: string,
): Promise<void> {
  await validateRemoteUrl(feedUrl);
  destinationDirectory(destinationPath);
}

function safeFilename(value: string): string {
  return value
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 160);
}

function reserveDownload(feed: FeedRow, entry: FeedEntry): number | null {
  const existing = sqlite
    .prepare("SELECT id FROM auto_downloads WHERE guid = ?")
    .get(entry.guid) as { id: number } | undefined;
  if (existing) return null;
  const result = sqlite
    .prepare(
      `INSERT INTO auto_downloads
         (feed_id, guid, title, source_url, destination_path, status, download_progress)
       VALUES (?, ?, ?, ?, ?, 'pending', 0)`,
    )
    .run(
      feed.id,
      entry.guid,
      entry.title,
      entry.url,
      feed.destination_path,
    );
  return Number(result.lastInsertRowid);
}

async function performDownload(
  jobId: number,
  sourceUrl: string,
  title: string,
  destinationPath: string,
): Promise<void> {
  let temporaryPath: string | null = null;
  try {
    const response = await fetchRemote(sourceUrl, 120_000);
    if (!response.ok || !response.body) {
      throw new Error(`Download source returned HTTP ${response.status}.`);
    }
    const source = new URL(sourceUrl);
    const extension = path.extname(source.pathname).toLowerCase();
    if (!supportedExtensions.has(extension)) {
      throw new Error("RSS item does not link to a supported media file.");
    }
    const contentLength = Number(response.headers.get("content-length") ?? 0);
    if (contentLength > maxDownloadBytes) {
      throw new Error("Download exceeds the configured maximum file size.");
    }

    const { directory } = destinationDirectory(destinationPath);
    const safeTitle = safeFilename(title) || `media-${jobId}`;
    const initialPath = path.join(directory, `${safeTitle}${extension}`);
    const finalPath = fs.existsSync(initialPath)
      ? path.join(directory, `${safeTitle}-${jobId}${extension}`)
      : initialPath;
    const tempPath = `${finalPath}.part-${jobId}`;
    temporaryPath = tempPath;
    const existingPath = sqlite
      .prepare("SELECT id FROM auto_downloads WHERE id = ?")
      .get(jobId) as { id: number } | undefined;
    if (!existingPath) throw new Error("Download job no longer exists.");

    sqlite
      .prepare("UPDATE auto_downloads SET status = 'downloading' WHERE id = ?")
      .run(jobId);

    let receivedBytes = 0;
    const progress = new Transform({
      transform(chunk: Buffer, _encoding, callback) {
        receivedBytes += chunk.length;
        if (receivedBytes > maxDownloadBytes) {
          callback(new Error("Download exceeded the configured maximum file size."));
          return;
        }
        if (contentLength > 0) {
          const percentage = Math.min(
            99,
            Math.floor((receivedBytes / contentLength) * 100),
          );
          sqlite
            .prepare(
              "UPDATE auto_downloads SET download_progress = ? WHERE id = ?",
            )
            .run(percentage, jobId);
        }
        callback(null, chunk);
      },
    });
    await pipeline(
      Readable.fromWeb(response.body as import("node:stream/web").ReadableStream),
      progress,
      fs.createWriteStream(tempPath, { flags: "wx" }),
    );
    fs.renameSync(tempPath, finalPath);
    temporaryPath = null;
    sqlite
      .prepare(
        `UPDATE auto_downloads
         SET status = 'completed', download_progress = 100, completed_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
      )
      .run(jobId);

    try {
      const scanResult = scanMediaLibrary();
      if (process.env.TMDB_API_KEY || process.env.LOCAL_AI_ENDPOINT) {
        const relativePath = path
          .relative(mediaRoot, finalPath)
          .split(path.sep)
          .join("/");
        const directItem = sqlite
          .prepare("SELECT id FROM media_items WHERE file_path = ?")
          .get(relativePath) as { id: number } | undefined;
        const episode = sqlite
          .prepare("SELECT media_id FROM episodes WHERE file_path = ?")
          .get(relativePath) as { media_id: number } | undefined;
        const metadataItemId = directItem?.id ?? episode?.media_id;
        if (metadataItemId) {
          try {
            await enrichMediaItem(metadataItemId);
          } catch (error) {
            logger.warn(
              {
                jobId,
                error:
                  error instanceof Error ? error.message : "Unknown metadata error",
              },
              "Automatic metadata enrichment failed",
            );
          }
        }
      }
      logger.info(
        { jobId, bytes: receivedBytes, scanned: scanResult.scanned },
        "RSS download completed and library rescanned",
      );
    } catch (error) {
      logger.warn(
        {
          jobId,
          error: error instanceof Error ? error.message : "Unknown scan error",
        },
        "Downloaded media could not be scanned",
      );
    }
  } catch (error) {
    if (temporaryPath) fs.rmSync(temporaryPath, { force: true });
    const message =
      error instanceof Error ? error.message : "Unknown download failure";
    sqlite
      .prepare(
        `UPDATE auto_downloads
         SET status = 'failed', error_message = ?
         WHERE id = ?`,
      )
      .run(message.slice(0, 500), jobId);
    logger.warn({ jobId, error: message }, "RSS download failed");
  }
}

let activeCheck: Promise<{ feedsChecked: number; jobsStarted: number }> | null =
  null;

export function checkRssFeeds(): Promise<{
  feedsChecked: number;
  jobsStarted: number;
}> {
  if (activeCheck) return activeCheck;
  activeCheck = (async () => {
    const feeds = sqlite
      .prepare(
        "SELECT * FROM rss_feeds WHERE enabled = 1 ORDER BY id ASC",
      )
      .all() as unknown as FeedRow[];
    let jobsStarted = 0;
    for (const feed of feeds) {
      try {
        const response = await fetchRemote(feed.feed_url, 15_000);
        if (!response.ok) {
          throw new Error(`RSS source returned HTTP ${response.status}.`);
        }
        const contentLength = Number(response.headers.get("content-length") ?? 0);
        if (contentLength > 2 * 1024 * 1024) {
          throw new Error("RSS feed is larger than 2 MB.");
        }
        const xml = await readLimitedText(response, 2 * 1024 * 1024);
        const entries = parseFeedEntries(xml);
        for (const entry of entries) {
          if (!matchesCriteria(entry.title, feed.match_criteria)) continue;
          if (
            !supportedExtensions.has(
              path.extname(new URL(entry.url).pathname).toLowerCase(),
            )
          ) {
            continue;
          }
          try {
            await validateRemoteUrl(entry.url);
          } catch {
            continue;
          }
          const jobId = reserveDownload(feed, entry);
          if (jobId === null) continue;
          jobsStarted += 1;
          void performDownload(
            jobId,
            entry.url,
            entry.title,
            feed.destination_path,
          );
        }
        sqlite
          .prepare(
            "UPDATE rss_feeds SET last_checked_at = CURRENT_TIMESTAMP WHERE id = ?",
          )
          .run(feed.id);
      } catch (error) {
        logger.warn(
          {
            feedId: feed.id,
            error: error instanceof Error ? error.message : "Unknown feed error",
          },
          "RSS feed check failed",
        );
      }
    }
    return { feedsChecked: feeds.length, jobsStarted };
  })().finally(() => {
    activeCheck = null;
  });
  return activeCheck;
}

let watcher: ReturnType<typeof setInterval> | undefined;

export function startDownloadsWatcher(): void {
  if (watcher) clearInterval(watcher);
  const intervalMinutes = Number(getSetting("watchIntervalMinutes") ?? 15);
  const intervalMs = Math.max(1, intervalMinutes) * 60_000;
  watcher = setInterval(() => {
    void checkRssFeeds().catch((error: unknown) => {
      logger.error(
        { error: error instanceof Error ? error.message : "Unknown error" },
        "RSS watcher cycle failed",
      );
    });
  }, intervalMs);
  watcher.unref();
  void checkRssFeeds();
}

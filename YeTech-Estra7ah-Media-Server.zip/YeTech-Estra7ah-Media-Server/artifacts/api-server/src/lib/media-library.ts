import fs from "node:fs";
import path from "node:path";
import { sqlite, type MediaRow, type MediaType } from "./sqlite";

export const mediaRoot = path.resolve(
  process.env.MEDIA_ROOT ??
    path.resolve(process.cwd(), "../../backend/media"),
);

const extensions: Record<string, MediaType> = {
  ".mp4": "movie",
  ".mkv": "movie",
  ".avi": "movie",
  ".mov": "movie",
  ".webm": "movie",
  ".m4v": "movie",
  ".m3u8": "movie",
  ".pdf": "book",
  ".epub": "book",
  ".mobi": "book",
  ".mp3": "audio",
  ".wav": "audio",
  ".m4a": "audio",
  ".aac": "audio",
  ".ogg": "audio",
  ".flac": "audio",
  ".apk": "app",
  ".zip": "app",
  ".exe": "app",
};

const folderTypes: Record<string, MediaType> = {
  video: "movie",
  movies: "movie",
  movie: "movie",
  series: "series",
  books: "book",
  book: "book",
  audio: "audio",
  app: "app",
  apps: "app",
  education: "education",
};

interface ScannedFile {
  absolutePath: string;
  relativePath: string;
  title: string;
  size: number;
  modifiedAt: string;
  type: MediaType;
}

interface ScannedSeries {
  title: string;
  filePath: string;
  category: string;
  episodes: Array<ScannedFile & { season: number; episode: number }>;
  totalBytes: number;
}

function cleanTitle(filename: string): string {
  return path
    .basename(filename, path.extname(filename))
    .replace(/[._-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getSeasonNumber(filePath: string): number {
  const seasonMatch = filePath.match(/season[\s._-]*(\d+)/i);
  return seasonMatch ? Number(seasonMatch[1]) : 1;
}

function getEpisodeNumber(filename: string, fallback: number): number {
  const match =
    filename.match(/s\d{1,2}[\s._-]*e(\d{1,3})/i) ??
    filename.match(/episode[\s._-]*(\d{1,3})/i) ??
    filename.match(/(?:^|[\s._-])(\d{1,3})(?:[\s._-]|$)/);
  return match ? Number(match[1]) : fallback;
}

function listMediaFiles(directory: string): ScannedFile[] {
  const results: ScannedFile[] = [];
  if (!fs.existsSync(directory)) return results;

  const visit = (currentDirectory: string): void => {
    for (const entry of fs.readdirSync(currentDirectory, {
      withFileTypes: true,
    })) {
      if (entry.name.startsWith(".")) continue;
      const absolutePath = path.join(currentDirectory, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) {
        visit(absolutePath);
        continue;
      }
      if (!entry.isFile()) continue;

      const type = extensions[path.extname(entry.name).toLowerCase()];
      if (!type) continue;
      const stats = fs.statSync(absolutePath);
      results.push({
        absolutePath,
        relativePath: path.relative(mediaRoot, absolutePath).split(path.sep).join("/"),
        title: cleanTitle(entry.name),
        size: stats.size,
        modifiedAt: stats.mtime.toISOString(),
        type,
      });
    }
  };

  visit(directory);
  return results;
}

function listSeries(directory: string): ScannedSeries[] {
  const results: ScannedSeries[] = [];
  if (!fs.existsSync(directory)) return results;

  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (!entry.isDirectory() || entry.isSymbolicLink() || entry.name.startsWith(".")) {
      continue;
    }
    const seriesDirectory = path.join(directory, entry.name);
    const files = listMediaFiles(seriesDirectory).filter((file) =>
      ["movie"].includes(file.type),
    );
    const episodes = files.map((file, index) => ({
      ...file,
      season: getSeasonNumber(file.relativePath),
      episode: getEpisodeNumber(file.title, index + 1),
    }));
    results.push({
      title: entry.name,
      filePath: `@series/${path.relative(mediaRoot, seriesDirectory).split(path.sep).join("/")}`,
      category: "series",
      episodes,
      totalBytes: episodes.reduce((sum, episode) => sum + episode.size, 0),
    });
  }
  return results;
}

export function safeMediaPath(relativePath: string): string | null {
  if (!relativePath || path.isAbsolute(relativePath)) return null;
  const fullPath = path.resolve(mediaRoot, relativePath);
  if (fullPath !== mediaRoot && !fullPath.startsWith(`${mediaRoot}${path.sep}`)) {
    return null;
  }
  try {
    const realRoot = fs.realpathSync(mediaRoot);
    const realFile = fs.realpathSync(fullPath);
    if (realFile !== realRoot && !realFile.startsWith(`${realRoot}${path.sep}`)) {
      return null;
    }
    return realFile;
  } catch {
    return null;
  }
}

export function getMediaRow(id: number): MediaRow | undefined {
  return sqlite
    .prepare("SELECT * FROM media_items WHERE id = ?")
    .get(id) as MediaRow | undefined;
}

export function getEpisodeRow(id: number):
  | {
      id: number;
      media_id: number;
      title: string;
      file_path: string;
      file_size: number;
      season_number: number;
      episode_number: number;
      duration: number | null;
    }
  | undefined {
  return sqlite
    .prepare("SELECT * FROM episodes WHERE id = ?")
    .get(id) as
    | {
        id: number;
        media_id: number;
        title: string;
        file_path: string;
        file_size: number;
        season_number: number;
        episode_number: number;
        duration: number | null;
      }
    | undefined;
}

export function mediaRowToApi(row: MediaRow) {
  const extension = path.extname(row.file_path).toLowerCase();
  return {
    id: row.id,
    title: row.title,
    type: row.type,
    category: row.category,
    posterUrl: row.poster_url,
    fileExtension: row.file_extension ?? (extension || null),
    mimeType: row.mime_type,
    overview: row.overview,
    releaseYear: row.release_year,
    language: row.language,
    metadataSource: row.metadata_source,
    lastModified: row.file_modified_at,
    fileSize: row.file_size,
    durationSeconds: row.duration,
    createdAt: new Date(`${row.created_at.replace(" ", "T")}Z`).toISOString(),
  };
}

export function scanMediaLibrary(): {
  scanned: number;
  added: number;
  updated: number;
  missing: number;
} {
  fs.mkdirSync(mediaRoot, { recursive: true });
  const presentPaths = new Set<string>();
  let scanned = 0;
  let added = 0;
  let updated = 0;

  const upsertMedia = (
    title: string,
    type: MediaType,
    filePath: string,
    fileSize: number,
    category: string,
    modifiedAt: string | null = null,
  ): number => {
    const isVirtualSeries = filePath.startsWith("@series/");
    const absolutePath = path.resolve(
      mediaRoot,
      isVirtualSeries ? filePath.slice("@series/".length) : filePath,
    );
    const fileExtension = isVirtualSeries
      ? null
      : path.extname(filePath).toLowerCase() || null;
    const mimeType = fileExtension ? getMimeType(filePath) : null;
    const existing = sqlite
      .prepare("SELECT id FROM media_items WHERE file_path = ?")
      .get(filePath) as { id: number } | undefined;
    sqlite
      .prepare(
        `INSERT INTO media_items
           (title, type, file_path, absolute_path, file_size, category, file_extension, mime_type, file_modified_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(file_path) DO UPDATE SET
           title = excluded.title,
           type = excluded.type,
           absolute_path = excluded.absolute_path,
           file_size = excluded.file_size,
           category = excluded.category,
           file_extension = excluded.file_extension,
           mime_type = excluded.mime_type,
           file_modified_at = excluded.file_modified_at,
           updated_at = CURRENT_TIMESTAMP`,
      )
      .run(
        title,
        type,
        filePath,
        absolutePath,
        fileSize,
        category,
        fileExtension,
        mimeType,
        modifiedAt,
      );
    if (existing) updated += 1;
    else added += 1;
    const row = sqlite
      .prepare("SELECT id FROM media_items WHERE file_path = ?")
      .get(filePath) as { id: number };
    return row.id;
  };

  sqlite.exec("BEGIN IMMEDIATE");
  try {
    for (const entry of fs.readdirSync(mediaRoot, { withFileTypes: true })) {
      if (!entry.isDirectory() || entry.isSymbolicLink()) continue;
      const category = entry.name.toLowerCase();
      const type = folderTypes[category];
      if (!type) continue;
      const categoryPath = path.join(mediaRoot, entry.name);

      if (type === "series") {
        for (const series of listSeries(categoryPath)) {
          scanned += series.episodes.length;
          presentPaths.add(series.filePath);
          const seriesId = upsertMedia(
            series.title,
            "series",
            series.filePath,
            series.totalBytes,
            series.category,
          );
          for (const episode of series.episodes) {
            presentPaths.add(episode.relativePath);
            const previous = sqlite
              .prepare("SELECT id FROM episodes WHERE file_path = ?")
              .get(episode.relativePath) as { id: number } | undefined;
            sqlite
              .prepare(
                `INSERT INTO episodes
                   (media_id, season_number, episode_number, title, file_path, file_size)
                 VALUES (?, ?, ?, ?, ?, ?)
                 ON CONFLICT(file_path) DO UPDATE SET
                   media_id = excluded.media_id,
                   season_number = excluded.season_number,
                   episode_number = excluded.episode_number,
                   title = excluded.title,
                   file_size = excluded.file_size`,
              )
              .run(
                seriesId,
                episode.season,
                episode.episode,
                episode.title,
                episode.relativePath,
                episode.size,
              );
            if (!previous) added += 1;
          }
        }
        continue;
      }

      for (const file of listMediaFiles(categoryPath)) {
        scanned += 1;
        presentPaths.add(file.relativePath);
        upsertMedia(
          file.title,
          type === "movie" ? "movie" : type,
          file.relativePath,
          file.size,
          entry.name,
          file.modifiedAt,
        );
      }
    }

    const priorItems = sqlite
      .prepare("SELECT file_path FROM media_items")
      .all() as Array<{ file_path: string }>;
    const priorEpisodes = sqlite
      .prepare("SELECT file_path FROM episodes")
      .all() as Array<{ file_path: string }>;
    const missing = [...priorItems, ...priorEpisodes].filter(
      (row) => !presentPaths.has(row.file_path),
    ).length;
    sqlite.exec("COMMIT");
    return { scanned, added, updated, missing };
  } catch (error) {
    sqlite.exec("ROLLBACK");
    throw error;
  }
}

export function parseMediaType(value: string): MediaType | null {
  return value in folderTypes || value in extensions
    ? (folderTypes[value] ?? extensions[value] ?? null)
    : null;
}

export function getMimeType(filePath: string): string {
  const mimeTypes: Record<string, string> = {
    ".mp4": "video/mp4",
    ".m4v": "video/mp4",
    ".mkv": "video/x-matroska",
    ".webm": "video/webm",
    ".avi": "video/x-msvideo",
    ".mov": "video/quicktime",
    ".m3u8": "application/vnd.apple.mpegurl",
    ".ts": "video/mp2t",
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".ogg": "audio/ogg",
    ".flac": "audio/flac",
    ".pdf": "application/pdf",
    ".epub": "application/epub+zip",
    ".mobi": "application/x-mobipocket-ebook",
    ".apk": "application/vnd.android.package-archive",
    ".zip": "application/zip",
    ".exe": "application/octet-stream",
  };
  return mimeTypes[path.extname(filePath).toLowerCase()] ?? "application/octet-stream";
}

export function mediaRootStatus(): { path: string; exists: boolean } {
  return { path: mediaRoot, exists: fs.existsSync(mediaRoot) };
}

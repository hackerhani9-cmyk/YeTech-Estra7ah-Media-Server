import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const projectRoot = path.resolve(process.cwd(), "../..");
const dataDirectory =
  process.env.DATA_DIR ?? path.join(projectRoot, "backend/data");
fs.mkdirSync(dataDirectory, { recursive: true });

const databasePath =
  process.env.DB_PATH ?? path.join(dataDirectory, "media.db");

export const sqlite = new DatabaseSync(databasePath);

sqlite.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  PRAGMA busy_timeout = 5000;

  CREATE TABLE IF NOT EXISTS media_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('movie', 'series', 'book', 'audio', 'app', 'education')),
    file_path TEXT NOT NULL UNIQUE,
    absolute_path TEXT,
    file_size INTEGER NOT NULL DEFAULT 0,
    file_extension TEXT,
    mime_type TEXT,
    file_modified_at TEXT,
    duration REAL,
    category TEXT,
    poster_url TEXT,
    overview TEXT,
    release_year INTEGER,
    language TEXT,
    genres_json TEXT NOT NULL DEFAULT '[]',
    tmdb_id INTEGER,
    metadata_source TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS episodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_id INTEGER NOT NULL REFERENCES media_items(id) ON DELETE CASCADE,
    season_number INTEGER NOT NULL DEFAULT 1,
    episode_number INTEGER NOT NULL DEFAULT 1,
    title TEXT NOT NULL,
    file_path TEXT NOT NULL UNIQUE,
    file_size INTEGER NOT NULL DEFAULT 0,
    duration REAL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (media_id, season_number, episode_number)
  );

  CREATE TABLE IF NOT EXISTS actors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    original_name TEXT,
    profile_path TEXT,
    biography TEXT,
    UNIQUE (name, original_name)
  );

  CREATE TABLE IF NOT EXISTS media_actors (
    media_id INTEGER NOT NULL REFERENCES media_items(id) ON DELETE CASCADE,
    actor_id INTEGER NOT NULL REFERENCES actors(id) ON DELETE CASCADE,
    character_name TEXT,
    cast_order INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (media_id, actor_id, character_name)
  );

  CREATE VIEW IF NOT EXISTS media_cast AS
    SELECT media_id, actor_id, character_name FROM media_actors;

  CREATE TABLE IF NOT EXISTS rss_feeds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    feed_url TEXT NOT NULL,
    destination_path TEXT NOT NULL,
    match_criteria TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    last_checked_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS auto_downloads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    feed_id INTEGER REFERENCES rss_feeds(id) ON DELETE SET NULL,
    guid TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    source_url TEXT NOT NULL,
    destination_path TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
      CHECK (status IN ('pending', 'downloading', 'completed', 'failed')),
    download_progress INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    error_message TEXT
  );

  CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_media_type ON media_items(type);
  CREATE INDEX IF NOT EXISTS idx_episode_media ON episodes(media_id, season_number, episode_number);
  CREATE INDEX IF NOT EXISTS idx_download_status ON auto_downloads(status, created_at);
`);

const mediaItemColumns = new Set(
  (
    sqlite.prepare("PRAGMA table_info(media_items)").all() as Array<{
      name: string;
    }>
  ).map((column) => column.name),
);
for (const [name, definition] of Object.entries({
  absolute_path: "TEXT",
  file_extension: "TEXT",
  mime_type: "TEXT",
  file_modified_at: "TEXT",
  language: "TEXT",
  metadata_source: "TEXT",
})) {
  if (!mediaItemColumns.has(name)) {
    sqlite.exec(`ALTER TABLE media_items ADD COLUMN ${name} ${definition}`);
  }
}

sqlite
  .prepare("INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)")
  .run("downloadLimitMbps", process.env.DOWNLOAD_LIMIT_MBPS ?? "0");
sqlite
  .prepare("INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)")
  .run("watchIntervalMinutes", process.env.WATCH_INTERVAL_MINUTES ?? "15");

export type MediaType =
  | "movie"
  | "series"
  | "book"
  | "audio"
  | "app"
  | "education";

export interface MediaRow {
  id: number;
  title: string;
  type: MediaType;
  file_path: string;
  absolute_path: string | null;
  file_size: number;
  file_extension: string | null;
  mime_type: string | null;
  file_modified_at: string | null;
  duration: number | null;
  category: string | null;
  poster_url: string | null;
  overview: string | null;
  release_year: number | null;
  language: string | null;
  genres_json: string;
  metadata_source: string | null;
  created_at: string;
  updated_at: string;
}

export function getSetting(key: string): string | undefined {
  const row = sqlite
    .prepare("SELECT value FROM app_settings WHERE key = ?")
    .get(key) as { value: string } | undefined;
  return row?.value;
}

export function setSetting(key: string, value: string): void {
  sqlite
    .prepare(
      `INSERT INTO app_settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    )
    .run(key, value);
}

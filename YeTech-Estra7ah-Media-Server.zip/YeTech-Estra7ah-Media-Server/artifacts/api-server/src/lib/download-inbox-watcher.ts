import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { logger } from "./logger";
import { mediaRoot, scanMediaLibrary } from "./media-library";

const downloadsRoot = path.resolve(
  process.env.DOWNLOADS_ROOT ??
    path.resolve(process.cwd(), "../../backend/downloads"),
);
const pollIntervalMs = Math.max(
  1_000,
  Number(process.env.DOWNLOADS_WATCH_INTERVAL_MS ?? 5_000),
);
const videoExtensions = new Set([".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v"]);
const audioExtensions = new Set([
  ".mp3",
  ".wav",
  ".m4a",
  ".aac",
  ".ogg",
  ".flac",
]);
const bookExtensions = new Set([".pdf", ".epub", ".mobi"]);
const appExtensions = new Set([".apk", ".zip", ".exe"]);

interface FileObservation {
  size: number;
  modifiedAt: number;
  stableScans: number;
}

const observations = new Map<string, FileObservation>();
let scanInProgress = false;

function safeSegment(value: string): string {
  return (
    value
      .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "")
      .replace(/\s+/g, " ")
      .replace(/[. ]+$/g, "")
      .trim()
      .slice(0, 100) || "Downloaded media"
  );
}

function collectFiles(directory: string, collected: string[] = []): string[] {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name.startsWith(".") || entry.isSymbolicLink()) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      collectFiles(fullPath, collected);
    } else if (entry.isFile()) {
      collected.push(fullPath);
    }
  }
  return collected;
}

function getDestination(filePath: string): string | null {
  const extension = path.extname(filePath).toLowerCase();
  const filename = path.basename(filePath);

  if (videoExtensions.has(extension)) {
    const episodeMatch = filename.match(/^(.*?)\s*[._ -]*S(\d{1,2})E(\d{1,3})/i);
    if (episodeMatch) {
      const seriesName = safeSegment(episodeMatch[1]);
      const season = Number(episodeMatch[2]);
      return path.join(
        "series",
        seriesName,
        `Season ${String(season).padStart(2, "0")}`,
        safeSegment(filename),
      );
    }
    return path.join("movies", safeSegment(filename));
  }
  if (audioExtensions.has(extension)) {
    return path.join("audio", safeSegment(filename));
  }
  if (bookExtensions.has(extension)) {
    return path.join("books", safeSegment(filename));
  }
  if (appExtensions.has(extension)) {
    return path.join("apps", safeSegment(filename));
  }
  return null;
}

function isInside(root: string, target: string): boolean {
  const relative = path.relative(root, target);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function collisionName(filePath: string, suffix: number): string {
  const extension = path.extname(filePath);
  const baseName = path.basename(filePath, extension);
  return path.join(
    path.dirname(filePath),
    `${baseName} (${suffix})${extension}`,
  );
}

async function moveWithoutOverwrite(sourcePath: string, desiredPath: string): Promise<string> {
  const directory = path.dirname(desiredPath);
  await fs.promises.mkdir(directory, { recursive: true });
  const realMediaRoot = await fs.promises.realpath(mediaRoot);
  const realDirectory = await fs.promises.realpath(directory);
  if (!isInside(realMediaRoot, realDirectory)) {
    throw new Error("Download destination resolves outside the media folder.");
  }

  for (let suffix = 0; ; suffix += 1) {
    const destination =
      suffix === 0 ? desiredPath : collisionName(desiredPath, suffix);
    try {
      const sourceBeforeMove = await fs.promises.stat(sourcePath);
      await fs.promises.link(sourcePath, destination);
      const sourceAfterMove = await fs.promises.stat(sourcePath);
      if (
        sourceAfterMove.size !== sourceBeforeMove.size ||
        sourceAfterMove.mtimeMs !== sourceBeforeMove.mtimeMs
      ) {
        await fs.promises.rm(destination, { force: true });
        throw new Error("Download file changed during finalization; it will be retried.");
      }
      await fs.promises.rm(sourcePath);
      return destination;
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      if (code === "EEXIST") continue;
      if (code !== "EXDEV") throw error;
      break;
    }
  }

  const temporaryPath = path.join(
    directory,
    `.incoming-${randomUUID()}`,
  );
  try {
    const sourceBeforeCopy = await fs.promises.stat(sourcePath);
    await fs.promises.copyFile(sourcePath, temporaryPath, fs.constants.COPYFILE_EXCL);
    const [sourceAfterCopy, temporaryStats] = await Promise.all([
      fs.promises.stat(sourcePath),
      fs.promises.stat(temporaryPath),
    ]);
    if (
      sourceAfterCopy.size !== sourceBeforeCopy.size ||
      sourceAfterCopy.mtimeMs !== sourceBeforeCopy.mtimeMs ||
      temporaryStats.size !== sourceBeforeCopy.size
    ) {
      await fs.promises.rm(temporaryPath, { force: true });
      throw new Error("Download file changed during finalization; it will be retried.");
    }

    for (let suffix = 0; ; suffix += 1) {
      const destination =
        suffix === 0 ? desiredPath : collisionName(desiredPath, suffix);
      try {
        await fs.promises.link(temporaryPath, destination);
        await fs.promises.rm(temporaryPath, { force: true });
        await fs.promises.rm(sourcePath);
        return destination;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "EEXIST") continue;
        throw error;
      }
    }
  } catch (error) {
    await fs.promises.rm(temporaryPath, { force: true }).catch(() => undefined);
    throw error;
  }
}

async function moveStableFile(sourcePath: string): Promise<string | null> {
  const relativeSource = path.relative(downloadsRoot, sourcePath);
  const resolvedSource = path.resolve(downloadsRoot, relativeSource);
  if (!isInside(downloadsRoot, resolvedSource)) {
    throw new Error("Download inbox path escaped its configured root.");
  }

  const destinationRelative = getDestination(sourcePath);
  if (!destinationRelative) return null;
  const destinationPath = path.resolve(mediaRoot, destinationRelative);
  if (!isInside(mediaRoot, destinationPath)) {
    throw new Error("Download destination escaped the media folder.");
  }
  return moveWithoutOverwrite(sourcePath, destinationPath);
}

async function scanInbox(): Promise<void> {
  if (scanInProgress) return;
  scanInProgress = true;
  try {
    fs.mkdirSync(downloadsRoot, { recursive: true });
    fs.mkdirSync(mediaRoot, { recursive: true });
    const files = collectFiles(downloadsRoot);
    const currentFiles = new Set(files);
    for (const observedPath of observations.keys()) {
      if (!currentFiles.has(observedPath)) observations.delete(observedPath);
    }

    const movedFiles: Array<{ source: string; destination: string }> = [];
    for (const filePath of files) {
      const extension = path.extname(filePath).toLowerCase();
      if (
        !videoExtensions.has(extension) &&
        !audioExtensions.has(extension) &&
        !bookExtensions.has(extension) &&
        !appExtensions.has(extension)
      ) {
        continue;
      }

      try {
        const stats = await fs.promises.stat(filePath);
        if (!stats.isFile() || stats.size === 0) continue;
        const previous = observations.get(filePath);
        const stableScans =
          previous &&
          previous.size === stats.size &&
          previous.modifiedAt === stats.mtimeMs
            ? previous.stableScans + 1
            : 1;
        observations.set(filePath, {
          size: stats.size,
          modifiedAt: stats.mtimeMs,
          stableScans,
        });
        if (stableScans < 3) continue;

        const destination = await moveStableFile(filePath);
        observations.delete(filePath);
        if (destination) movedFiles.push({ source: filePath, destination });
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          observations.delete(filePath);
          continue;
        }
        logger.warn(
          {
            filePath,
            error: error instanceof Error ? error.message : "Unknown inbox error",
          },
          "Download inbox item was not moved",
        );
      }
    }

    if (movedFiles.length > 0) {
      try {
        const result = scanMediaLibrary();
        logger.info(
          { movedFiles, ...result },
          "Completed download inbox files moved and indexed",
        );
      } catch (error) {
        logger.error(
          {
            movedFiles,
            error: error instanceof Error ? error.message : "Unknown scan error",
          },
          "Moved download inbox files but could not refresh the media index",
        );
      }
    }
  } catch (error) {
    logger.error(
      { error: error instanceof Error ? error.message : "Unknown inbox error" },
      "Download inbox scan failed",
    );
  } finally {
    scanInProgress = false;
  }
}

export function startDownloadInboxWatcher(): void {
  fs.mkdirSync(downloadsRoot, { recursive: true });
  void scanInbox();
  const interval = setInterval(() => void scanInbox(), pollIntervalMs);
  interval.unref();
  logger.info(
    { downloadsRoot, pollIntervalMs },
    "Download inbox watcher started",
  );
}

import { sqlite } from "./sqlite";

interface TmdbSearchResult {
  id: number;
  title?: string;
  name?: string;
  overview?: string;
  poster_path?: string | null;
  release_date?: string;
  first_air_date?: string;
}

interface TmdbCredit {
  id: number;
  name: string;
  original_name?: string;
  profile_path?: string | null;
  character?: string;
  roles?: Array<{ character?: string }>;
  order?: number;
}

export class MetadataProviderMissingError extends Error {
  constructor() {
    super(
      "Configure TMDB_API_KEY or LOCAL_AI_ENDPOINT on the server to enable metadata enrichment.",
    );
    this.name = "MetadataProviderMissingError";
  }
}

async function tmdbRequest<T>(pathname: string, apiKey: string): Promise<T> {
  const url = new URL(`https://api.themoviedb.org/3/${pathname}`);
  url.searchParams.set("api_key", apiKey);
  url.searchParams.set("language", "en-US");
  const response = await fetch(url, {
    signal: AbortSignal.timeout(12_000),
    headers: { accept: "application/json" },
  });
  if (!response.ok) {
    throw new Error(`Metadata provider returned HTTP ${response.status}.`);
  }
  return (await response.json()) as T;
}

interface LocalAiResult {
  overview: string | null;
  genres: string[];
  releaseYear: number | null;
  language: string | null;
}

async function localAiMetadata(
  title: string,
  mediaType: string,
): Promise<LocalAiResult | null> {
  const endpoint = process.env.LOCAL_AI_ENDPOINT;
  if (!endpoint) return null;
  const model = process.env.LOCAL_AI_MODEL ?? "local-model";
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify({
      model,
      temperature: 0.1,
      messages: [
        {
          role: "system",
          content:
            "Return one JSON object with overview, genres (array of strings), releaseYear (integer or null), and language (short language code or null). Use only reliable facts. Leave uncertain fields empty; do not invent cast or plot facts.",
        },
        {
          role: "user",
          content: `Suggest metadata for this ${mediaType} title: ${title}`,
        },
      ],
    }),
    signal: AbortSignal.timeout(20_000),
  });
  if (!response.ok) {
    throw new Error(`Local AI provider returned HTTP ${response.status}.`);
  }
  const result = (await response.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const rawContent = result.choices?.[0]?.message?.content;
  if (!rawContent) throw new Error("Local AI provider returned no metadata.");
  const jsonText = rawContent
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "");
  const parsed = JSON.parse(jsonText) as {
    overview?: unknown;
    genres?: unknown;
    releaseYear?: unknown;
    language?: unknown;
  };
  const currentYear = new Date().getFullYear() + 2;
  const releaseYear =
    typeof parsed.releaseYear === "number" &&
    Number.isInteger(parsed.releaseYear) &&
    parsed.releaseYear >= 1888 &&
    parsed.releaseYear <= currentYear
      ? parsed.releaseYear
      : null;
  return {
    overview:
      typeof parsed.overview === "string"
        ? parsed.overview.trim().slice(0, 4_000) || null
        : null,
    genres: Array.isArray(parsed.genres)
      ? parsed.genres
          .filter((genre): genre is string => typeof genre === "string")
          .map((genre) => genre.trim().slice(0, 80))
          .filter(Boolean)
          .slice(0, 12)
      : [],
    releaseYear,
    language:
      typeof parsed.language === "string"
        ? parsed.language.trim().slice(0, 16) || null
        : null,
  };
}

function storeLocalAiMetadata(
  id: number,
  metadata: LocalAiResult,
): { status: "completed" | "skipped"; message: string } {
  if (!metadata.overview && metadata.genres.length === 0 && !metadata.releaseYear) {
    return {
      status: "skipped",
      message: "The local AI provider returned no usable metadata.",
    };
  }
  const genresJson = JSON.stringify(metadata.genres);
  sqlite.exec("BEGIN IMMEDIATE");
  try {
    sqlite
      .prepare(
        `UPDATE media_items
         SET overview = COALESCE(?, overview),
             release_year = COALESCE(?, release_year),
             language = COALESCE(?, language),
             genres_json = CASE WHEN ? = '[]' THEN genres_json ELSE ? END,
             metadata_source = 'local-ai',
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
      )
      .run(
        metadata.overview,
        metadata.releaseYear,
        metadata.language,
        genresJson,
        genresJson,
        id,
      );
    sqlite.exec("COMMIT");
  } catch (error) {
    sqlite.exec("ROLLBACK");
    throw error;
  }
  return {
    status: "completed",
    message: "Metadata was enriched by the configured local AI provider.",
  };
}

export async function enrichMediaItem(
  id: number,
): Promise<{ status: "completed" | "skipped"; message: string }> {
  const apiKey = process.env.TMDB_API_KEY;
  const hasLocalAi = Boolean(process.env.LOCAL_AI_ENDPOINT);
  if (!apiKey && !hasLocalAi) throw new MetadataProviderMissingError();

  const item = sqlite
    .prepare("SELECT id, title, type FROM media_items WHERE id = ?")
    .get(id) as { id: number; title: string; type: string } | undefined;
  if (!item) throw new Error("Media item not found.");
  if (item.type !== "movie" && item.type !== "series") {
    return {
      status: "skipped",
      message: "Online cast enrichment is available for movies and series.",
    };
  }

  const localMetadata = hasLocalAi
    ? await localAiMetadata(item.title, item.type)
    : null;
  if (!apiKey) {
    if (!localMetadata) throw new MetadataProviderMissingError();
    return storeLocalAiMetadata(id, localMetadata);
  }

  const kind = item.type === "series" ? "tv" : "movie";
  const search = await tmdbRequest<{ results?: TmdbSearchResult[] }>(
    `search/${kind}?query=${encodeURIComponent(item.title)}&include_adult=false`,
    apiKey,
  );
  const candidate = search.results?.[0];
  if (!candidate) {
    if (localMetadata) return storeLocalAiMetadata(id, localMetadata);
    return {
      status: "skipped",
      message: "No matching title was found by the metadata provider.",
    };
  }

  const detail = await tmdbRequest<{
    id: number;
    overview?: string;
    poster_path?: string | null;
    release_date?: string;
    first_air_date?: string;
    original_language?: string;
    genres?: Array<{ name: string }>;
  }>(`${kind}/${candidate.id}`, apiKey);
  const creditsPath =
    kind === "tv"
      ? `tv/${candidate.id}/aggregate_credits`
      : `movie/${candidate.id}/credits`;
  const credits = await tmdbRequest<{ cast?: TmdbCredit[] }>(
    creditsPath,
    apiKey,
  );
  const cast = (credits.cast ?? []).slice(0, 30);
  const posterUrl = detail.poster_path
    ? `https://image.tmdb.org/t/p/w500${detail.poster_path}`
    : candidate.poster_path
      ? `https://image.tmdb.org/t/p/w500${candidate.poster_path}`
      : null;
  const yearText =
    detail.release_date ??
    detail.first_air_date ??
    candidate.release_date ??
    candidate.first_air_date;
  const releaseYear = yearText ? Number(yearText.slice(0, 4)) || null : null;
  const genres = detail.genres?.length
    ? detail.genres.map((genre) => genre.name)
    : (localMetadata?.genres ?? []);
  const overview =
    detail.overview || candidate.overview || localMetadata?.overview || null;
  const genresJson = JSON.stringify(genres);

  sqlite.exec("BEGIN IMMEDIATE");
  try {
    sqlite
      .prepare(
        `UPDATE media_items
         SET poster_url = COALESCE(?, poster_url),
             overview = COALESCE(?, overview),
             release_year = COALESCE(?, release_year),
             language = COALESCE(?, language),
             genres_json = CASE WHEN ? = '[]' THEN genres_json ELSE ? END,
             tmdb_id = ?, metadata_source = ?, updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
      )
      .run(
        posterUrl,
        overview,
        releaseYear ?? localMetadata?.releaseYear ?? null,
        detail.original_language ?? localMetadata?.language ?? null,
        genresJson,
        genresJson,
        candidate.id,
        localMetadata ? "tmdb+local-ai" : "tmdb",
        id,
      );
    sqlite.prepare("DELETE FROM media_actors WHERE media_id = ?").run(id);
    const insertActor = sqlite.prepare(
      `INSERT INTO actors (name, original_name, profile_path)
       VALUES (?, ?, ?)
       ON CONFLICT(name, original_name) DO UPDATE SET
         profile_path = COALESCE(excluded.profile_path, actors.profile_path)`,
    );
    const findActor = sqlite.prepare(
      "SELECT id FROM actors WHERE name = ? AND original_name IS ?",
    );
    const insertCast = sqlite.prepare(
      `INSERT OR IGNORE INTO media_actors
         (media_id, actor_id, character_name, cast_order)
       VALUES (?, ?, ?, ?)`,
    );
    for (const [index, actor] of cast.entries()) {
      if (!actor.name) continue;
      const profilePath = actor.profile_path
        ? `https://image.tmdb.org/t/p/w185${actor.profile_path}`
        : null;
      const characterName =
        actor.character ??
        actor.roles?.map((role) => role.character).filter(Boolean).join(", ") ??
        null;
      insertActor.run(
        actor.name,
        actor.original_name ?? null,
        profilePath,
      );
      const storedActor = findActor.get(
        actor.name,
        actor.original_name ?? null,
      ) as { id: number } | undefined;
      if (storedActor) {
        insertCast.run(id, storedActor.id, characterName, actor.order ?? index);
      }
    }
    sqlite.exec("COMMIT");
  } catch (error) {
    sqlite.exec("ROLLBACK");
    throw error;
  }

  return {
    status: "completed",
    message: `Metadata and ${cast.length} cast members were updated.`,
  };
}

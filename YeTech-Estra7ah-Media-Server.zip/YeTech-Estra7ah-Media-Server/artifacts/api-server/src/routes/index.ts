import { Router, type IRouter } from "express";
import healthRouter from "./health";
import mediaRouter from "./media";
import downloadsRouter from "./downloads";
import settingsRouter from "./settings";

const router: IRouter = Router();

router.use(healthRouter);
router.use(mediaRouter);
router.use(downloadsRouter);
router.use(settingsRouter);

export default router;

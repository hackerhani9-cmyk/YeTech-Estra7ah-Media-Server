import { Router, type IRouter } from "express";
import {
  CheckRssFeedsResponse,
  CreateRssFeedBody,
  CreateRssFeedResponse,
  DeleteRssFeedParams,
  DeleteRssFeedResponse,
  GetDownloadJobsResponse,
  GetRssFeedsResponse,
} from "@workspace/api-zod";
import { checkRssFeeds, validateFeedConfiguration } from "../lib/rss-watcher";
import { sqlite } from "../lib/sqlite";

const router: IRouter = Router();

router.get("/downloads/feeds", (_req, res): void => {
  const rows = sqlite
    .prepare("SELECT * FROM rss_feeds ORDER BY created_at DESC")
    .all() as Array<{
    id: number;
    title: string;
    feed_url: string;
    destination_path: string;
    match_criteria: string | null;
    enabled: number;
    last_checked_at: string | null;
  }>;
  res.json(
    GetRssFeedsResponse.parse(
      rows.map((row) => ({
        id: row.id,
        title: row.title,
        feedUrl: row.feed_url,
        destinationPath: row.destination_path,
        matchCriteria: row.match_criteria,
        enabled: Boolean(row.enabled),
        lastCheckedAt: row.last_checked_at
          ? new Date(`${row.last_checked_at.replace(" ", "T")}Z`).toISOString()
          : null,
      })),
    ),
  );
});

router.post("/downloads/feeds", async (req, res): Promise<void> => {
  const parsed = CreateRssFeedBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await validateFeedConfiguration(
      parsed.data.feedUrl,
      parsed.data.destinationPath,
    );
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Invalid feed settings.",
    });
    return;
  }
  const result = sqlite
    .prepare(
      `INSERT INTO rss_feeds
         (title, feed_url, destination_path, match_criteria, enabled)
       VALUES (?, ?, ?, ?, ?)`,
    )
    .run(
      parsed.data.title.trim(),
      parsed.data.feedUrl,
      parsed.data.destinationPath,
      parsed.data.matchCriteria ?? null,
      parsed.data.enabled ? 1 : 0,
    );
  const feed = {
    id: Number(result.lastInsertRowid),
    title: parsed.data.title.trim(),
    feedUrl: parsed.data.feedUrl,
    destinationPath: parsed.data.destinationPath,
    matchCriteria: parsed.data.matchCriteria ?? null,
    enabled: parsed.data.enabled ?? true,
    lastCheckedAt: null,
  };
  res.status(201).json(CreateRssFeedResponse.parse(feed));
});

router.delete("/downloads/feeds/:id", (req, res): void => {
  const params = DeleteRssFeedParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const result = sqlite
    .prepare("DELETE FROM rss_feeds WHERE id = ?")
    .run(params.data.id);
  if (result.changes === 0) {
    res.status(404).json({ error: "RSS watcher not found." });
    return;
  }
  res.status(204).json(DeleteRssFeedResponse.parse(undefined));
});

router.get("/downloads/jobs", (_req, res): void => {
  const rows = sqlite
    .prepare(
      `SELECT id, title, source_url, destination_path, status,
              download_progress, created_at, completed_at
       FROM auto_downloads
       ORDER BY created_at DESC
       LIMIT 100`,
    )
    .all() as Array<{
    id: number;
    title: string;
    source_url: string;
    destination_path: string;
    status: "pending" | "downloading" | "completed" | "failed";
    download_progress: number;
    created_at: string;
    completed_at: string | null;
  }>;
  res.json(
    GetDownloadJobsResponse.parse(
      rows.map((row) => ({
        id: row.id,
        title: row.title,
        sourceUrl: row.source_url,
        destinationPath: row.destination_path,
        status: row.status,
        downloadProgress: row.download_progress,
        createdAt: new Date(`${row.created_at.replace(" ", "T")}Z`).toISOString(),
        completedAt: row.completed_at
          ? new Date(`${row.completed_at.replace(" ", "T")}Z`).toISOString()
          : null,
      })),
    ),
  );
});

router.post("/downloads/check", async (_req, res): Promise<void> => {
  const result = await checkRssFeeds();
  res.json(CheckRssFeedsResponse.parse({ ...result, message: "Feed check completed." }));
});

export default router;

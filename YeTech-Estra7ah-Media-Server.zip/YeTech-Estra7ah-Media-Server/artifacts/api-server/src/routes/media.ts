import fs from "node:fs";
import path from "node:path";
import { Transform } from "node:stream";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  DownloadMediaParams,
  EnrichMediaItemParams,
  EnrichMediaItemResponse,
  GetMediaItemParams,
  GetMediaItemResponse,
  GetMediaItemsQueryParams,
  GetMediaItemsResponse,
  GetMediaStatsResponse,
  ScanMediaLibraryResponse,
  StreamHlsAssetParams,
  StreamMediaParams,
} from "@workspace/api-zod";
import { enrichMediaItem, MetadataProviderMissingError } from "../lib/enrichment";
import {
  getEpisodeRow,
  getMediaRow,
  getMimeType,
  mediaRoot,
  mediaRowToApi,
  safeMediaPath,
  scanMediaLibrary,
} from "../lib/media-library";
import { getSetting, sqlite } from "../lib/sqlite";

const router: IRouter = Router();
const byteRangeChunkSize = 1024 * 1024;
const clientThrottleStates = new Map<
  string,
  { nextAt: number; activeStreams: number }
>();

function respondWithFile(
  req: Request,
  res: Response,
  filePath: string,
  download: boolean,
  bandwidthLimitMbps = 0,
): void {
  let stat: fs.Stats;
  try {
    stat = fs.statSync(filePath);
  } catch {
    res.status(404).json({ error: "Media file is missing from the media folder." });
    return;
  }
  if (!stat.isFile()) {
    res.status(404).json({ error: "Media file not found." });
    return;
  }

  const size = stat.size;
  const rangeHeader = download ? undefined : req.headers.range;
  let start = 0;
  let end = size - 1;
  if (rangeHeader) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader.trim());
    if (!match || size === 0) {
      res.setHeader("Content-Range", `bytes */${size}`);
      res.status(416).end();
      return;
    }
    if (match[1] === "") {
      const suffixLength = Number(match[2]);
      if (!Number.isFinite(suffixLength) || suffixLength <= 0) {
        res.setHeader("Content-Range", `bytes */${size}`);
        res.status(416).end();
        return;
      }
      start = Math.max(0, size - suffixLength);
    } else {
      start = Number(match[1]);
      end = match[2] === "" ? size - 1 : Number(match[2]);
    }
    if (
      !Number.isFinite(start) ||
      !Number.isFinite(end) ||
      start < 0 ||
      start >= size ||
      end < start
    ) {
      res.setHeader("Content-Range", `bytes */${size}`);
      res.status(416).end();
      return;
    }
    end = Math.min(end, size - 1);
  }

  const chunkLength = end - start + 1;
  res.setHeader("Content-Type", getMimeType(filePath));
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("Content-Length", chunkLength);
  if (download) {
    const filename = encodeURIComponent(filePath.split(/[\\/]/).pop() ?? "download");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${filename}`);
  }
  if (rangeHeader) {
    res.status(206);
    res.setHeader("Content-Range", `bytes ${start}-${end}/${size}`);
  }

  if (download && bandwidthLimitMbps > 0) {
    const clientId = req.ip || req.socket.remoteAddress || "unknown";
    const throttleState =
      clientThrottleStates.get(clientId) ??
      { nextAt: Date.now(), activeStreams: 0 };
    throttleState.activeStreams += 1;
    clientThrottleStates.set(clientId, throttleState);
    const bytesPerSecond = bandwidthLimitMbps * 125_000;
    const limiter = new Transform({
      transform(chunk: Buffer, _encoding, callback) {
        const now = Date.now();
        const scheduledStart = Math.max(now, throttleState.nextAt);
        throttleState.nextAt =
          scheduledStart + (chunk.length / bytesPerSecond) * 1000;
        setTimeout(
          () => callback(null, chunk),
          Math.max(0, scheduledStart - now),
        );
      },
    });
    const file = fs.createReadStream(filePath, {
      start,
      end,
      highWaterMark: byteRangeChunkSize,
    });
    file.on("error", () => {
      if (!res.headersSent) res.status(404).end();
      else res.destroy();
    });
    limiter.on("error", () => res.destroy());
    res.on("close", () => {
      throttleState.activeStreams -= 1;
      if (throttleState.activeStreams <= 0) {
        clientThrottleStates.delete(clientId);
      }
      file.destroy();
      limiter.destroy();
    });
    file.pipe(limiter).pipe(res);
    return;
  }

  const file = fs.createReadStream(filePath, {
    start,
    end,
    highWaterMark: byteRangeChunkSize,
  });
  file.on("error", () => {
    if (!res.headersSent) res.status(404).end();
    else res.destroy();
  });
  file.pipe(res);
}

function getPlayablePath(id: number, episodeMode: boolean): string | null {
  const media = episodeMode ? undefined : getMediaRow(id);
  const episode = episodeMode ? getEpisodeRow(id) : undefined;
  const relativePath = media?.file_path ?? episode?.file_path;
  if (!relativePath || relativePath.startsWith("@series/")) return null;
  return safeMediaPath(relativePath);
}

function rewriteHlsUri(
  mediaId: number,
  playlistPath: string,
  baseDirectory: string,
  uri: string,
  episodeMode: boolean,
): string {
  if (/^(?:https?:|data:|blob:)/i.test(uri)) return uri;
  const uriWithoutSuffix = uri.split(/[?#]/, 1)[0];
  let decodedUri = uriWithoutSuffix;
  try {
    decodedUri = decodeURIComponent(uriWithoutSuffix);
  } catch {
    return uri;
  }
  const resolved = path.resolve(path.dirname(playlistPath), decodedUri);
  const relativePath = path.relative(mediaRoot, resolved).split(path.sep).join("/");
  const assetPath = safeMediaPath(relativePath);
  if (
    !assetPath ||
    (assetPath !== baseDirectory &&
      !assetPath.startsWith(`${baseDirectory}${path.sep}`))
  ) {
    return uri;
  }
  const encodedPath = Buffer.from(relativePath).toString("base64url");
  return `/api/hls/${mediaId}/${encodedPath}${episodeMode ? "?episode=true" : ""}`;
}

function sendHlsPlaylist(
  mediaId: number,
  playlistPath: string,
  baseDirectory: string,
  episodeMode: boolean,
  res: Response,
): void {
  let source: string;
  try {
    source = fs.readFileSync(playlistPath, "utf8");
  } catch {
    res.status(404).json({ error: "HLS playlist not found." });
    return;
  }
  if (Buffer.byteLength(source, "utf8") > 2 * 1024 * 1024) {
    res.status(413).json({ error: "HLS playlist exceeds the 2 MB limit." });
    return;
  }
  const rewritten = source
    .split(/\r?\n/)
    .map((line) => {
      if (!line.trim()) return line;
      if (line.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/g, (_match, uri: string) => {
          const nextUri = rewriteHlsUri(
            mediaId,
            playlistPath,
            baseDirectory,
            uri,
            episodeMode,
          );
          return `URI="${nextUri}"`;
        });
      }
      return rewriteHlsUri(
        mediaId,
        playlistPath,
        baseDirectory,
        line.trim(),
        episodeMode,
      );
    })
    .join("\n");
  res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("Content-Length", Buffer.byteLength(rewritten, "utf8"));
  res.send(rewritten);
}

router.get("/media/stats", (_req, res): void => {
  const totalRow = sqlite
    .prepare("SELECT COUNT(*) AS total, COALESCE(SUM(file_size), 0) AS total_bytes FROM media_items")
    .get() as { total: number; total_bytes: number };
  const byType = sqlite
    .prepare(
      "SELECT type, COUNT(*) AS count FROM media_items GROUP BY type ORDER BY type",
    )
    .all() as Array<{ type: string; count: number }>;
  res.json(
    GetMediaStatsResponse.parse({
      total: totalRow.total,
      totalBytes: totalRow.total_bytes,
      byType: byType.map((row) => ({ type: row.type, count: row.count })),
    }),
  );
});

router.get("/media/items", (req, res): void => {
  const parsed = GetMediaItemsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, type, limit, offset } = parsed.data;
  const clauses: string[] = [];
  const params: Array<string | number> = [];
  if (type) {
    clauses.push("type = ?");
    params.push(type);
  }
  if (search?.trim()) {
    clauses.push("(LOWER(title) LIKE ? OR LOWER(COALESCE(overview, '')) LIKE ?)");
    const term = `%${search.trim().toLocaleLowerCase()}%`;
    params.push(term, term);
  }
  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
  const rows = sqlite
    .prepare(
      `SELECT * FROM media_items ${where}
       ORDER BY created_at DESC, title COLLATE NOCASE ASC
       LIMIT ? OFFSET ?`,
    )
    .all(...params, limit, offset) as unknown as Parameters<
      typeof mediaRowToApi
    >[0][];
  res.json(GetMediaItemsResponse.parse(rows.map(mediaRowToApi)));
});

router.get("/media/items/:id", (req, res): void => {
  const params = GetMediaItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const row = getMediaRow(params.data.id);
  if (!row) {
    res.status(404).json({ error: "Media item not found." });
    return;
  }
  const cast = sqlite
    .prepare(
      `SELECT a.id, a.name, a.original_name, a.profile_path, ma.character_name
       FROM media_actors ma
       JOIN actors a ON a.id = ma.actor_id
       WHERE ma.media_id = ?
       ORDER BY ma.cast_order ASC`,
    )
    .all(row.id) as Array<{
    id: number;
    name: string;
    original_name: string | null;
    profile_path: string | null;
    character_name: string | null;
  }>;
  const episodes = sqlite
    .prepare(
      `SELECT id, season_number, episode_number, title, file_path, file_size, duration
       FROM episodes
       WHERE media_id = ?
       ORDER BY season_number ASC, episode_number ASC`,
    )
    .all(row.id) as Array<{
    id: number;
    season_number: number;
    episode_number: number;
    title: string;
    file_path: string;
    file_size: number;
    duration: number | null;
  }>;
  let genres: string[] = [];
  try {
    const parsedGenres = JSON.parse(row.genres_json) as unknown;
    if (Array.isArray(parsedGenres)) {
      genres = parsedGenres.filter((genre): genre is string => typeof genre === "string");
    }
  } catch {
    genres = [];
  }
  res.json(
    GetMediaItemResponse.parse({
      ...mediaRowToApi(row),
      genres,
      cast: cast.map((actor) => ({
        id: actor.id,
        name: actor.name,
        originalName: actor.original_name,
        profilePath: actor.profile_path,
        characterName: actor.character_name,
      })),
      episodes: episodes.map((episode) => ({
        id: episode.id,
        seasonNumber: episode.season_number,
        episodeNumber: episode.episode_number,
        title: episode.title,
        fileExtension: path.extname(episode.file_path).toLowerCase() || null,
        fileSize: episode.file_size,
        durationSeconds: episode.duration,
      })),
    }),
  );
});

router.post("/media/scan", (_req, res): void => {
  try {
    const result = scanMediaLibrary();
    res.json(ScanMediaLibraryResponse.parse(result));
  } catch (error) {
    res.status(500).json({
      error: error instanceof Error ? error.message : "Library scan failed.",
    });
  }
});

router.post("/media/items/:id/enrich", async (req, res): Promise<void> => {
  const params = EnrichMediaItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  try {
    const result = await enrichMediaItem(params.data.id);
    res.json(
      EnrichMediaItemResponse.parse({
        itemId: params.data.id,
        status: result.status,
        message: result.message,
      }),
    );
  } catch (error) {
    if (error instanceof MetadataProviderMissingError) {
      res.status(503).json({ error: error.message });
      return;
    }
    const message =
      error instanceof Error ? error.message : "Metadata enrichment failed.";
    res.status(message === "Media item not found." ? 404 : 502).json({ error: message });
  }
});

router.get("/stream/:id", (req, res): void => {
  const params = StreamMediaParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const episodeMode = req.query.episode === "true";
  const filePath = getPlayablePath(params.data.id, episodeMode);
  if (!filePath) {
    res.status(404).json({ error: "Media file not found." });
    return;
  }
  if (path.extname(filePath).toLowerCase() === ".m3u8") {
    sendHlsPlaylist(
      params.data.id,
      filePath,
      path.dirname(filePath),
      episodeMode,
      res,
    );
    return;
  }
  respondWithFile(req, res, filePath, false);
});

router.get("/hls/:id/:asset", (req, res): void => {
  const params = StreamHlsAssetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const episodeMode = req.query.episode === "true";
  const playlistPath = getPlayablePath(params.data.id, episodeMode);
  if (!playlistPath) {
    res.status(404).json({ error: "Media item not found." });
    return;
  }
  let relativePath: string;
  try {
    relativePath = Buffer.from(params.data.asset, "base64url").toString("utf8");
  } catch {
    res.status(400).json({ error: "Invalid HLS asset path." });
    return;
  }
  if (!relativePath || path.isAbsolute(relativePath)) {
    res.status(400).json({ error: "Invalid HLS asset path." });
    return;
  }
  const assetPath = safeMediaPath(relativePath);
  const baseDirectory = path.dirname(playlistPath);
  if (
    !assetPath ||
    (assetPath !== baseDirectory &&
      !assetPath.startsWith(`${baseDirectory}${path.sep}`))
  ) {
    res.status(404).json({ error: "HLS asset is outside the media folder." });
    return;
  }
  if (path.extname(assetPath).toLowerCase() === ".m3u8") {
    sendHlsPlaylist(
      params.data.id,
      assetPath,
      baseDirectory,
      episodeMode,
      res,
    );
    return;
  }
  respondWithFile(req, res, assetPath, false);
});

router.get("/download/:id", (req, res): void => {
  const params = DownloadMediaParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const media = getMediaRow(params.data.id);
  if (!media || !["book", "app", "education"].includes(media.type)) {
    res.status(404).json({ error: "Downloadable media not found." });
    return;
  }
  const filePath = safeMediaPath(media.file_path);
  if (!filePath) {
    res.status(404).json({ error: "Media file is unavailable." });
    return;
  }
  const limit = Number(getSetting("downloadLimitMbps") ?? 0);
  respondWithFile(req, res, filePath, true, Number.isFinite(limit) ? limit : 0);
});

export default router;

import { Router, type IRouter } from "express";
import {
  GetServerSettingsResponse,
  UpdateServerSettingsBody,
  UpdateServerSettingsResponse,
} from "@workspace/api-zod";
import { startDownloadsWatcher } from "../lib/rss-watcher";
import { getSetting, setSetting } from "../lib/sqlite";

const router: IRouter = Router();

function currentSettings() {
  return {
    downloadLimitMbps: Number(getSetting("downloadLimitMbps") ?? 0),
    watchIntervalMinutes: Number(getSetting("watchIntervalMinutes") ?? 15),
    metadataProviderConfigured: Boolean(
      process.env.TMDB_API_KEY || process.env.LOCAL_AI_ENDPOINT,
    ),
  };
}

router.get("/settings", (_req, res): void => {
  res.json(GetServerSettingsResponse.parse(currentSettings()));
});

router.patch("/settings", (req, res): void => {
  const parsed = UpdateServerSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (Object.keys(parsed.data).length === 0) {
    res.status(400).json({ error: "At least one setting is required." });
    return;
  }
  if (parsed.data.downloadLimitMbps !== undefined) {
    setSetting("downloadLimitMbps", String(parsed.data.downloadLimitMbps));
  }
  if (parsed.data.watchIntervalMinutes !== undefined) {
    setSetting(
      "watchIntervalMinutes",
      String(parsed.data.watchIntervalMinutes),
    );
    startDownloadsWatcher();
  }
  res.json(UpdateServerSettingsResponse.parse(currentSettings()));
});

export default router;
